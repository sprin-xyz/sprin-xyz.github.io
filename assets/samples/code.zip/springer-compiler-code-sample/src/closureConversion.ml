open Asts;;
open Freshening;;
open Utils;;

let rec free_vars (e : expr) : StringSet.t =
    match e with
    | EInt _ | EBool _ -> StringSet.empty
    | EUnaryOp (op, e') -> free_vars e'
    | EBinaryOp (op, exp1, exp2) ->
        StringSet.union (free_vars exp1) (free_vars exp2)
    | ETuple (exprs) ->
        let sets = List.map free_vars exprs in 
        List.fold_left (fun acc el -> StringSet.union acc el) StringSet.empty sets
    | ELet (str, exp1, exp2) ->
        StringSet.union (free_vars exp1) (StringSet.remove str (free_vars exp2))
    | EVar (str) ->
        StringSet.add str StringSet.empty
    | EIfNonZero (exp1, exp2, exp3) | EIf (exp1, exp2, exp3) | ESet (exp1, exp2, exp3) ->
        StringSet.union (StringSet.union (free_vars exp1) (free_vars exp2)) (free_vars exp3)
    | EAppl (exp1, exp2, bol) ->
        StringSet.union (free_vars exp1) (free_vars exp2)
    | ELambda (param, e') ->
        StringSet.remove param (free_vars e')
;;


let rec create_eappl (name : string) (l : string list) : expr =
    match l with
    | [] -> EVar(name)
    | first::rest ->
        let applied_fn = create_eappl name rest in
        EAppl(applied_fn, EVar(first), false)
;;

let rec closure_convert_expression (e : expr) : expr * declaration list =
    match e with
    | EInt (i) -> EInt(i), []
    | EBool (truthiness) -> EBool(truthiness), []
    | EUnaryOp (op, e') ->
        let (e'', decls) = closure_convert_expression e' in
        EUnaryOp(op, e''), decls
    | EBinaryOp (op, exp1, exp2) ->
        let (exp1', decls1) = closure_convert_expression exp1 in
        let (exp2', decls2) = closure_convert_expression exp2 in
        EBinaryOp(op, exp1', exp2'), decls1 @ decls2
    | ETuple (exprs) ->
        let expr_decls = List.map closure_convert_expression exprs in
        let (exprs', decls) = List.split expr_decls in
        let decls' = List.concat decls in
        ETuple(exprs'), decls'
    | ELet (str, exp1, exp2) ->
        let (exp1', decls1) = closure_convert_expression exp1 in
        let (exp2', decls2) = closure_convert_expression exp2 in
        ELet(str, exp1', exp2'), decls1 @ decls2
    | EVar (str) -> EVar(str), []
    | EIfNonZero (exp1, exp2, exp3) ->
        let (exp1', decls1) = closure_convert_expression exp1 in
        let (exp2', decls2) = closure_convert_expression exp2 in
        let (exp3', decls3) = closure_convert_expression exp3 in
        EIfNonZero(exp1', exp2', exp3'), decls1 @ decls2 @ decls3
    | EIf (exp1, exp2, exp3) ->
        let (exp1', decls1) = closure_convert_expression exp1 in
        let (exp2', decls2) = closure_convert_expression exp2 in
        let (exp3', decls3) = closure_convert_expression exp3 in
        EIf(exp1', exp2', exp3'), decls1 @ decls2 @ decls3
    | EAppl (exp1, exp2, bol) ->
        let (exp1', decls1) = closure_convert_expression exp1 in
        let (exp2', decls2) = closure_convert_expression exp2 in
        EAppl(exp1', exp2', bol), decls1 @ decls2
    | ELambda (param, e') ->
        let new_name = fresh_name "$norussian$" in
        let out_of_scope_vars_without_param = StringSet.remove param (free_vars e') in
        let out_of_scope_vars_without_param_list = (StringSet.elements out_of_scope_vars_without_param) in
        let params_list = out_of_scope_vars_without_param_list @ [param] in
        let out_of_scope_vars_without_param_list_reversed = List.rev out_of_scope_vars_without_param_list in
        let (e'', decls) = closure_convert_expression e' in
        let decls' = decls @ [DFunction(new_name, params_list, e'')] in
        let e''' = create_eappl new_name out_of_scope_vars_without_param_list_reversed in
        e''', decls'
    | ESet (exp1, exp2, exp3) ->
        let (exp1', decls1) = closure_convert_expression exp1 in
        let (exp2', decls2) = closure_convert_expression exp2 in
        let (exp3', decls3) = closure_convert_expression exp3 in
        ESet(exp1', exp2', exp3'), decls1 @ decls2 @ decls3
;;

let closure_convert_declaration (decl : declaration) : declaration list =
    let DFunction(x, y, z) = decl in
    let (z', decls) = closure_convert_expression z in
    decls @ [DFunction(x, y, z')]
;;

let no_russian (p : program) : program =
    let Program(decls, e) = p in
    let (e', main_decls) = closure_convert_expression e in
    let combined_decls = main_decls @ List.concat (List.map closure_convert_declaration decls) in
    Program(combined_decls, e') 
;;
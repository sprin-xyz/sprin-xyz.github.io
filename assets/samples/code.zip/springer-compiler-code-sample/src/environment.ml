(* This file contains the data structure and functions we will use to manage
   the environment as we compile our code. *)

open Batteries;;
open AssemblyLanguage;;
open Utils;;

(* This data type represents the kind of environment we will use in our
   compiler. *)
type environment = argument StringMap.t * int * int;;

(* This defines an exception which should be thrown if we try to read from an
   environment something that doesn't exist. *)
exception UnboundVariable of string * environment;;

(* The value representing an empty environment.  The map is empty and zero
   temporary locations are in use. *)
let empty_environment : environment = (StringMap.empty, -4, 0);;

let assign_name (env : environment) (name : string) (arg : argument) : environment =
  let (map, offset, params) = env in
  (StringMap.add name arg map, offset, params)
;;

let alloc_temp (env : environment) : environment * argument =
  let (map, offset, params) = env in
  ((map, offset - 4, params), ArgMemory(AddressByRegisterOffset(EBP, offset)))
;;

let alloc_var (env : environment) (key : string) : environment * argument =
  let (map, offset, params) = env in
  let addr = (ArgMemory(AddressByRegisterOffset(EBP, offset))) in
  ((StringMap.add key addr map, offset - 4, params), addr)
;;

let alloc_function_argument (env : environment) (key : string) (v : int) : environment =
  let (map, offset, params) = env in
  let addr = (ArgMemory(AddressByRegisterOffset(EBP, v))) in
  (StringMap.add key addr map, offset, params)
;;

let lookup_var (env : environment) (key : string) : argument =
  let (map, offset, params) = env in
  try
    StringMap.find key map
  with Not_found -> raise (UnboundVariable (key, env))
;;

let set_num_function_params (env : environment) (yint : int) : environment =
  let (map, offset, params) = env in
  (map, offset, yint)
;;

let get_num_function_params (env : environment) : int =
  let (map, offset, params) = env in
  params
;;

let string_of_environment (env : environment) : string =
  "ArgMemory(AddressByRegisterOffset(EBP, eh))"
;;

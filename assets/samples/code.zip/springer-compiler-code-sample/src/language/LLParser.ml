(*
This file defines an LL parser for Pyrrhuloxia.
*)

open Batteries;;

open Asts;;
open LLLexer;;

(** This exception should be raised if an error occurs during parsing. *)
exception ParserError of string;;

(** A helper function which attempts to parse the prefix of a token stream into
    an expression.  It takes as an argument a list of mini-parsers: functions
    which *try* to recognize a specific expression and raise a ParserError if
    they fail. *)
let rec parse_first_of
    (parsers : (token list -> expr * token list) list)
    (input : token list)
  : expr * token list =
  match parsers with
  | [] ->
    (* We have no routines to use to find a parser.  Give up, producing an error
       message to hint to the user where we were in the file. *)
    let max_error_length = 50 in
    let first_part_of_token_stream = List.take max_error_length input in
    let stream_string =
      String.join ", " (List.map show_token first_part_of_token_stream)
    in
    raise (ParserError(
        Printf.sprintf "Failed to parse expression from tokens: %s"
          stream_string))
  | parser :: parsers' ->
    try
      (* If this parser successfully produces a result, use it! *)
      parser input
    with
    | ParserError _ ->
      (* This parser failed.  Let's try the next one. *)
      parse_first_of parsers' input
;;

(** A routine which attempts to parse a general expression. *)
let rec parse_expr (input : token list) : expr * token list =
  parse_first_of
  [
    parse_let_expr;
    parse_ifnz_expr;
    parse_if_expr;
    parse_lamba_expr;
    parse_tuple_set;
    parse_or_expr;
  ]
  input

and parse_lamba_expr (input : token list) : expr * token list =
  match input with
  | TokFun :: TokIdentifier param :: TokArrow :: rest ->
    let (e, rest') = parse_expr rest in
    (ELambda(param, e), rest')
  | _ -> raise (ParserError "not a lambda")

and parse_tuple_set (input : token list) : expr * token list =
  let (hopefully_a_tuple, rest) = parse_or_expr input in
  match rest with
  | TokSet :: rest' ->
    (
    match hopefully_a_tuple with
    | EBinaryOp(OpTupleIndex, t, i) ->
      let (e, rest'') = parse_expr rest' in
      (ESet(t, i, e), rest'')
    | _ -> raise (ParserError "not a set")
    )
  | _ -> raise (ParserError "not a set")

and parse_let_expr (input : token list) : expr * token list =
  match input with
  | TokLet :: TokIdentifier var :: TokEquals :: rest ->
    let (e1, rest') = parse_expr rest in
    (
    match rest' with
    | TokIn :: rest'' ->
      let (e2, rest''') = parse_expr rest'' in
      (ELet(var, e1, e2), rest''')
    | _ -> raise (ParserError "Could not parse a let expr")
    )
  | _ -> raise (ParserError "Could not parse a let expr")

and parse_ifnz_expr (input : token list) : expr * token list =
  match input with
  | TokIfnz :: rest ->
    let (e1, rest') = parse_expr rest in
    (
    match rest' with
    | TokThen :: rest'' ->
      let (e2, rest''') = parse_expr rest'' in
      (
      match rest''' with
      | TokElse :: restiv ->
        let (e3, restv) = parse_expr restiv in
        (EIfNonZero(e1,e2,e3), restv)
      | _ -> raise (ParserError "Could not parse a ifnz expr")
      )
    | _ -> raise (ParserError "Could not parse a ifnz expr")
    )
  | _ -> raise (ParserError "Could not parse a ifnz expr")

and parse_if_expr (input : token list) : expr * token list =
  match input with
  | TokIf :: rest ->
    let (e1, rest') = parse_expr rest in
    (
    match rest' with
    | TokThen :: rest'' ->
      let (e2, rest''') = parse_expr rest'' in
      (
      match rest''' with
      | TokElse :: restiv ->
        let (e3, restv) = parse_expr restiv in
        (EIf(e1,e2,e3), restv)
      | _ -> raise (ParserError "Could not parse a if expr")
      )
    | _ -> raise (ParserError "Could not parse a if expr")
    )
  | _ -> raise (ParserError "Could not parse a if expr")

and parse_or_expr (input : token list) : expr * token list =
  let (e, input') = parse_and_expr input in
  let rec loop (loop_input : token list)
    : (binary_operator * expr) list * token list =
    match loop_input with
    | TokOr :: loop_input' ->
      let (e, loop_input'') = parse_and_expr loop_input' in
      let (rest_exprs, rest_input) = loop loop_input'' in
      ((OpOr, e) :: rest_exprs, rest_input)
    | _ ->
      ([], loop_input)
  in
  let (op_exprs, input'') = loop input' in
  let result =
    List.fold_left
      (fun e1 (op,e2) -> EBinaryOp(op,e1,e2))
      e
      op_exprs
  in
  (result, input'')

and parse_and_expr (input : token list) : expr * token list =
  let (e, input') = parse_comparison_expr input in
  let rec loop (loop_input : token list)
    : (binary_operator * expr) list * token list =
    match loop_input with
    | TokAnd :: loop_input' ->
      let (e, loop_input'') = parse_comparison_expr loop_input' in
      let (rest_exprs, rest_input) = loop loop_input'' in
      ((OpAnd, e) :: rest_exprs, rest_input)
    | _ ->
      ([], loop_input)
  in
  let (op_exprs, input'') = loop input' in
  let result =
    List.fold_left
      (fun e1 (op,e2) -> EBinaryOp(op,e1,e2))
      e
      op_exprs
  in
  (result, input'')

and parse_comparison_expr (input : token list) : expr * token list =
  let (e, input') = parse_additive_expr input in
  let rec loop (loop_input : token list)
    : (binary_operator * expr) list * token list =
    match loop_input with
    | TokEquals :: loop_input' ->
      let (e, loop_input'') = parse_additive_expr loop_input' in
      let (rest_exprs, rest_input) = loop loop_input'' in
      ((OpEqualTo, e) :: rest_exprs, rest_input)
    | TokLessThan :: loop_input' ->
      let (e, loop_input'') = parse_additive_expr loop_input' in
      let (rest_exprs, rest_input) = loop loop_input'' in
      ((OpLessThan, e) :: rest_exprs, rest_input)
    | TokGreaterThan :: loop_input' ->
      let (e, loop_input'') = parse_additive_expr loop_input' in
      let (rest_exprs, rest_input) = loop loop_input'' in
      ((OpGreaterThan, e) :: rest_exprs, rest_input)
    | _ ->
      ([], loop_input)
  in
  let (op_exprs, input'') = loop input' in
  let result =
    List.fold_left
      (fun e1 (op,e2) -> EBinaryOp(op,e1,e2))
      e
      op_exprs
  in
  (result, input'')

(** A routine which attempts to parse an additive expression. *)
and parse_additive_expr (input : token list) : expr * token list =
  (* Read the first primary expr. *)
  let (e, input') = parse_multiplicative_expr input in
  (* In a loop, find each following "+expr" or "-expr".  Put them in a list and
     return that along with the remaining tokens. *)
  let rec loop (loop_input : token list)
    : (binary_operator * expr) list * token list =
    match loop_input with
    | TokPlus :: loop_input' ->
      (* A + is next.  See if we can get an expression after it. *)
      let (e, loop_input'') = parse_multiplicative_expr loop_input' in
      let (rest_exprs, rest_input) = loop loop_input'' in
      (* We found a + and an expression.  Store them and keep trying. *)
      ((OpPlus, e) :: rest_exprs, rest_input)
    | TokMinus :: loop_input' ->
      let (e, loop_input'') = parse_multiplicative_expr loop_input' in
      let (rest_exprs, rest_input) = loop loop_input'' in
      ((OpMinus, e) :: rest_exprs, rest_input)
    | _ ->
      (* We couldn't find a "+ expr", but that's okay; we'll just use what we
         have. *)
      ([], loop_input)
  in
  (* Find all of the operations we want to attach to this expr. *)
  let (op_exprs, input'') = loop input' in
  (* For each "+expr" or "-expr", build an AST from left to right which
     describes these operations. *)
  let result =
    List.fold_left
      (fun e1 (op,e2) -> EBinaryOp(op,e1,e2))
      e
      op_exprs
  in
  (result, input'')

and parse_multiplicative_expr (input : token list) : expr * token list =
  let (e, input') = parse_unary_op input in
  let rec loop (loop_input : token list)
    : (binary_operator * expr) list * token list =
    match loop_input with
    | TokTimes :: loop_input' ->
      let (e, loop_input'') = parse_unary_op loop_input' in
      let (rest_exprs, rest_input) = loop loop_input'' in
      ((OpTimes, e) :: rest_exprs, rest_input)
    | _ ->
      ([], loop_input)
  in
  let (op_exprs, input'') = loop input' in
  let result =
    List.fold_left
      (fun e1 (op,e2) -> EBinaryOp(op,e1,e2))
      e
      op_exprs
  in
  (result, input'')

and parse_unary_op (input : token list) : expr * token list = 
  (* Zach note: should do all unarys here but I want to apply to unary ops so they are primary exprs *)
  (* Needed to do this instead of negation at the top (negation = unary op) for function application *)
  match input with
  | TokMinus :: input' ->
    let (e, rest) = parse_tuple_index input' in
    (EBinaryOp(OpMinus, EInt(0), e), rest)
  | _ -> parse_tuple_index input

and parse_tuple_index (input : token list) : expr * token list = 
  let (hopefully_a_tuple, rest) = parse_applicative_expr input in
  match rest with
  | TokOpenBrac :: rest' ->
    let (index, rest'') = parse_expr rest' in
    (
    match rest'' with
    | TokCloseBrac::rest''' ->
      (EBinaryOp(OpTupleIndex, hopefully_a_tuple, index), rest''')
    | _ -> parse_applicative_expr input
    )
  | _ -> parse_applicative_expr input

and parse_applicative_expr (input : token list) : expr * token list =
  let (e, input') = parse_primary_expr input in
  let rec loop (loop_input : token list)
    : expr list * token list =
    if List.is_empty loop_input then
      ([], [])
    else
      try
        let (e, loop_input') = parse_primary_expr loop_input in
        let (rest_exprs, rest_input) = loop loop_input' in
        (e :: rest_exprs, rest_input)
      with
      | ParserError _ -> ([], loop_input) 
  in
  let (op_exprs, input'') = loop input' in
  let result =
    List.fold_left
      (fun e1 e2 -> EAppl(e1, e2, false))
      e
      op_exprs
  in
  (result, input'') 

(** A routine which attempts to parse a primary expression. *)
and parse_primary_expr (input : token list) : expr * token list =
  parse_first_of
    [ 
      parse_true;
      parse_false;
      parse_int_expr;
      parse_identifier;
      parse_after_expr;
      parse_before_expr;
      parse_print_expr;
      parse_isint_expr;
      parse_isbool_expr;
      parse_istuple_expr;
      parse_tuple;
      parse_paren_expr;
    ]
    input

and parse_expression_list (current_exprs : expr list) (tokens : token list) : expr list * token list =
  let (e, rest) = parse_expr tokens in
  match rest with
  | TokComma :: rest' -> parse_expression_list (e::current_exprs) rest'
  | TokCloseParen :: rest' -> (e::current_exprs, rest)
  | _ -> raise (ParserError "")

and parse_tuple (tokens : token list) : expr * token list =
  match tokens with
  | TokOpenParen :: rest ->
    let (rev_exprs, rest') = parse_expression_list [] rest in
    let exprs = List.rev rev_exprs in
    if List.length exprs < 2 then
      raise (ParserError "this is a parenthetical expr not a tuple")
    else
      (
      match rest' with
      | TokCloseParen :: rest'' -> (ETuple(exprs), rest'')
      | _ -> raise (ParserError "there isn't a close paren for this tuple")
      )
  | _ -> raise (ParserError "not a tuple")

(** A routine which attempts to parse the integer production of a primary
    expression. *)
and parse_int_expr (input : token list) : expr * token list =
  match input with
  | TokInt n :: input' ->
    (EInt n, input')
  | _ ->
    raise (ParserError("Failed to parse integer"))

(** A routine which attempts to parse the parenthesis production of a primary
    expression. *)
and parse_paren_expr (input : token list) : expr * token list =
  match input with
  | TokOpenParen :: input' ->
    begin
      let (e, input'') = parse_expr input' in
      match input'' with
      | TokCloseParen :: input''' ->
        (e, input''')
      | _ ->
        raise (ParserError("Failed to parse expression: missing close paren"))
    end
  | _ ->
    raise (ParserError("Failed to parse expression: missing open paren"))

and parse_true (input : token list) : expr * token list =
 match input with
  | TokTrue :: input' ->
    (EBool true, input')
  | _ ->
    raise (ParserError("Failed to parse true"))

and parse_false (input : token list) : expr * token list =
 match input with
  | TokFalse :: input' ->
    (EBool false, input')
  | _ ->
    raise (ParserError("Failed to parse false"))

and parse_identifier (input : token list) : expr * token list =
 match input with
  | TokIdentifier s :: input' ->
    (EVar s, input')
  | _ ->
    raise (ParserError("Failed to parse identifier"))

and parse_after_expr (input : token list) : expr * token list =
 match input with
  | TokAfter :: input' ->
    (
    try
      let (e, input'') = parse_paren_expr input' in
      (EUnaryOp(OpAfter, e), input'')
    with
    | ParserError e -> raise (ParserError("Failed to parse after"))
    )
  |_ ->
    raise (ParserError("Failed to parse after"))

and parse_before_expr (input : token list) : expr * token list =
 match input with
  | TokBefore :: input' ->
    (
    try
      let (e, input'') = parse_paren_expr input' in
      (EUnaryOp(OpBefore, e), input'')
    with
    | ParserError e -> raise (ParserError("Failed to parse before"))
    )
  |_ ->
    raise (ParserError("Failed to parse before"))

and parse_print_expr (input : token list) : expr * token list =
 match input with
  | TokPrint :: input' ->
    (
    try
      let (e, input'') = parse_paren_expr input' in
      (EUnaryOp(OpPrint, e), input'')
    with
    | ParserError e -> raise (ParserError("Failed to parse print"))
    )
  |_ ->
    raise (ParserError("Failed to parse print"))

and parse_isint_expr (input : token list) : expr * token list =
 match input with
  | TokIsInt :: input' ->
    (
    try
      let (e, input'') = parse_paren_expr input' in
      (EUnaryOp(OpIsInt, e), input'')
    with
    | ParserError e -> raise (ParserError("Failed to parse isint"))
    )
  |_ ->
    raise (ParserError("Failed to parse isint"))

and parse_isbool_expr (input : token list) : expr * token list =
 match input with
  | TokIsBool :: input' ->
    (
    try
      let (e, input'') = parse_paren_expr input' in
      (EUnaryOp(OpIsBool, e), input'')
    with
    | ParserError e -> raise (ParserError("Failed to parse isbool"))
    )
  |_ ->
    raise (ParserError("Failed to parse isbool"))

and parse_istuple_expr (input : token list) : expr * token list =
 match input with
  | TokIsTuple :: input' ->
    (
    try
      let (e, input'') = parse_paren_expr input' in
      (EUnaryOp(OpIsTuple, e), input'')
    with
    | ParserError e -> raise (ParserError("Failed to parse istuple"))
    )
  |_ ->
    raise (ParserError("Failed to parse istuple"))
;;

let rec parse_paramater_list (current_params : string list) (tokens : token list) : string list * token list =
  match tokens with
  | TokIdentifier(x) :: rest -> parse_paramater_list (x::current_params) rest
  | _ -> (current_params, tokens)
;;

let parse_decl (tokens : token list) : declaration * token list =
  match tokens with
  | TokDef :: TokIdentifier name :: rest ->
    let (reversed_params, rest') = parse_paramater_list [] rest in
    let params = List.rev reversed_params in
    if List.is_empty params then
      raise (ParserError ("No params detected in function " ^ name))
    else
      (
      match rest' with
      | TokEquals :: rest'' ->
        let (e, rest''') = parse_expr rest'' in
        let max_error_length = 50 in
        let first_part_of_token_stream = List.take max_error_length rest''' in
        let stream_string =
          String.join ", " (List.map show_token first_part_of_token_stream)
        in
        (
        match rest''' with
        | TokEnd :: restiv -> (DFunction(name, params, e), restiv)
        | _ -> raise (ParserError ("No end token in function " ^ name ^ "\n\n" ^ stream_string))
        )
      | _ -> raise (ParserError ("No = after definition in function " ^ name))
      )
  | _ -> raise (ParserError "no more decls")
;;

let rec parse_decls (current_decls : declaration list) (tokens : token list) : declaration list * token list =
  try
    let (d, tokens') = parse_decl tokens in
    parse_decls (d::current_decls) tokens'
  with
  | ParserError "no more decls" -> (current_decls, tokens)
;;

(** This function attempts to transform a list of tokens into a program.  If
    this process is unsuccessful, a ParserError is raised. *)
let parse (tokens : token list) : program =
  let (reversed_decls, tokens') = parse_decls [] tokens in
  let decls = List.rev reversed_decls in
  let (e, extras) = parse_expr tokens' in
  if List.is_empty extras then
    Program(decls,e)
  else
    let stream_string = String.join ", " (List.map show_token extras) in
    raise (ParserError(Printf.sprintf "Extraneous tokens during parse: %s"
                         stream_string))
;;

(*
This file defines a lexer for an LL parser generator for Pyrrhuloxia.
*)

open Batteries;;

(** An exception type which should be raised when lexing fails. *)
exception LexerError of string;;

(** The type of tokens produced by this lexer. *)
type token =
  | TokInt of int
  | TokIdentifier of string
  | TokTrue
  | TokFalse
  | TokPlus
  | TokMinus
  | TokTimes
  | TokLessThan
  | TokGreaterThan
  | TokEquals
  | TokAnd
  | TokOr
  | TokOpenBrac
  | TokCloseBrac
  | TokComma
  | TokSet
  | TokOpenParen
  | TokCloseParen

  | TokLet
  | TokIn
  | TokIf
  | TokThen
  | TokElse
  | TokAfter
  | TokBefore
  | TokPrint
  | TokIsBool
  | TokIsInt
  | TokIsTuple
  | TokDef
  | TokEnd
  | TokIfnz
  | TokFun
  | TokArrow
[@@deriving eq, ord, show];;

(** A helper function which attempts to lex the prefix of a string into a token.
    It takes as an argument a list of mini-lexers: functions which *try* to
    recognize a specific token and raise a LexerError if they fail. *)
let rec tokenize_first_of
    (tokenizers : (char list -> token * char list) list)
    (input : char list)
  : token * char list =
  match tokenizers with
  | [] ->
    (* We have no routines to use to find a token.  Give up, producing an error
       message to hint to the user where we were in the file. *)
    let max_error_length = 20 in
    let first_part_of_string =
      String.of_list (List.take max_error_length input)
    in
    raise (LexerError(Printf.sprintf "Unrecognized token starting at: \"%s\""
                        first_part_of_string))
  | tokenizer :: tokenizers' ->
    try
      (* If this tokenizer successfully produces a result, use it! *)
      tokenizer input
    with
    | LexerError _ ->
      (* This tokenizer failed.  Let's try the next one. *)
      tokenize_first_of tokenizers' input
;;

(** This routine discards whitespace from the input stream. *)
let discard_whitespace (input : char list) : char list =
  List.drop_while Char.is_whitespace input
;;

(** This routine attempts to lex a single numeric token from the input.
    Note that this routine does NOT handle negative numbers. *)
let tokenize_int (input : char list) : token * char list =
  (* Get all of the digits from the front of the input that we can. *)
  let digits = List.take_while Char.is_digit input in
  let rest = List.drop_while Char.is_digit input in
  (* If we didn't get any digits, then the next token isn't an integer. *)
  if List.is_empty digits then
    raise (LexerError "Could not tokenize integer")
  else
    (* Convert the list of digits into a string. *)
    let digit_string = String.of_list digits in
    (* Turn that into a number. *)
    let number = int_of_string digit_string in
    (* Return a token with that number along with the rest of the input. *)
    (TokInt number, rest)
;;

let rec list_starts_with (prefix : 'a list) (lst : 'a list) : bool =
  match prefix with
  | [] -> true
  | first::rest ->
    match lst with
    | [] -> false
    | first'::rest' -> first = first' && (list_starts_with rest rest')
;;

let is_identifier_char (c : char) : bool =
  Char.is_digit c || Char.is_letter c || c = '_'
;;

let tokenize_symbol (symbol : string) (tok : token) (input : char list) : token * char list =
  if (list_starts_with (String.to_list symbol) input) then
    let rest = List.drop (String.length symbol) input in
    (tok, rest)
  else
    raise (LexerError ("Could not tokenize a " ^ symbol))
;;

let tokenize_identifier (input : char list) : token * char list =
  let identifier = List.take_while is_identifier_char input in
  let rest = List.drop_while is_identifier_char input in
  if List.is_empty identifier then
    raise (LexerError "Could not tokenize identifier")
  else
    (TokIdentifier (String.of_list identifier), rest)
;;

let tokenize_keyword (keyword : string) (tok : token) (input : char list) : token * char list =
  if (list_starts_with (String.to_list keyword) input) then
    let rest = List.drop (String.length keyword) input in
    match rest with
    | [] -> (tok, rest)
    | first::rest' -> 
      if is_identifier_char first then raise (LexerError ("Could not tokenize a " ^ keyword))
      else (tok, rest)
  else
    raise (LexerError ("Could not tokenize a " ^ keyword))
;;

let tokenize_plus = tokenize_symbol "+" TokPlus;;
let tokenize_minus = tokenize_symbol "-" TokMinus;;
let tokenize_times = tokenize_symbol "*" TokTimes;;
let tokenize_less_than = tokenize_symbol "<" TokLessThan;;
let tokenize_greater_than = tokenize_symbol ">" TokGreaterThan;;
let tokenize_equals = tokenize_symbol "=" TokEquals;;
let tokenize_and = tokenize_symbol "&&" TokAnd;;
let tokenize_or = tokenize_symbol "||" TokOr;;
let tokenize_comma = tokenize_symbol "," TokComma;;
let tokenize_set = tokenize_symbol ":=" TokSet;;
let tokenize_open_brac = tokenize_symbol "[" TokOpenBrac;;
let tokenize_close_brac = tokenize_symbol "]" TokCloseBrac;;
let tokenize_open_paren = tokenize_symbol "(" TokOpenParen;;
let tokenize_close_paren = tokenize_symbol ")" TokCloseParen;;
let tokenize_arrow = tokenize_symbol "->" TokArrow;;

let tokenize_let = tokenize_keyword "let" TokLet;;
let tokenize_in = tokenize_keyword "in" TokIn;;
let tokenize_if = tokenize_keyword "if" TokIf;;
let tokenize_then = tokenize_keyword "then" TokThen;;
let tokenize_else = tokenize_keyword "else" TokElse;;
let tokenize_after = tokenize_keyword "after" TokAfter;;
let tokenize_before = tokenize_keyword "before" TokBefore;;
let tokenize_print = tokenize_keyword "print" TokPrint;;
let tokenize_isbool = tokenize_keyword "isbool" TokIsBool;;
let tokenize_isint = tokenize_keyword "isint" TokIsInt;;
let tokenize_istuple = tokenize_keyword "istuple" TokIsTuple;;
let tokenize_true = tokenize_keyword "true" TokTrue;;
let tokenize_false = tokenize_keyword "false" TokFalse;;
let tokenize_def = tokenize_keyword "def" TokDef;;
let tokenize_end = tokenize_keyword "end" TokEnd;;
let tokenize_ifnz = tokenize_keyword "ifnz" TokIfnz;;
let tokenize_fun = tokenize_keyword "fun" TokFun;;

(** This routine attempts to take a single token from the input stream.  If an
    unrecoverable error occurs, a LexerError is raised. *)
let tokenize (input : char list) : token * char list =
  tokenize_first_of
    [ 
      tokenize_and;
      tokenize_close_brac;
      tokenize_close_paren;
      tokenize_comma;
      tokenize_equals;
      tokenize_arrow;
      tokenize_greater_than;
      tokenize_int;
      tokenize_less_than;
      tokenize_minus;
      tokenize_open_brac;
      tokenize_open_paren;
      tokenize_or;
      tokenize_plus;
      tokenize_set;
      tokenize_times;

      tokenize_let;
      tokenize_in;
      tokenize_if;
      tokenize_then;
      tokenize_else;
      tokenize_after;
      tokenize_before;
      tokenize_print;
      tokenize_isbool;
      tokenize_isint;
      tokenize_istuple;
      tokenize_true;
      tokenize_false;
      tokenize_def;
      tokenize_end;
      tokenize_ifnz;
      tokenize_fun;

      tokenize_identifier;
    ]
    input
;;

(** A function to lex a string.  If lexing is successful, a list of tokens is
    returned.  Otherwise, a LexerError is raised. *)
let lex (text : string) : token list =
  let input = String.to_list text in
  (*
    This function recursively takes a token from the input stream.  It builds up
    a list in *reverse* order because this allows it to tail recurse; the
    list is reversed once the routine is complete.
  *)
  let rec take_tokens (tokens_so_far : token list) (input : char list)
    : token list =
    (* Get rid of any leading whitespace. *)
    let input' = discard_whitespace input in
    (* If we're out of input, then return the list of tokens we have. *)
    if List.is_empty input' then
      tokens_so_far
    else
      (* Take a token from the input. *)
      let (token, input'') = tokenize input' in
      (* Recurse to take more tokens.  Note that the new token is put on the
         front of the list, resulting in the list being constructed in backwards
         order.  This is reversed later.  Doing things this way allows us to
         tail recurse here!  :-D *)
      take_tokens (token :: tokens_so_far) input''
  in
  List.rev (take_tokens [] input)
;;

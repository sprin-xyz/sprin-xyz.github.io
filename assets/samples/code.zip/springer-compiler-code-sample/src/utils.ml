(* THIS FILE WAS PROVIDED BY THE INSTRUCTOR *)

(*
 *
  This code creates a "module" which defines a dictionary data type with keys
  of type string.  The syntax below is probably pretty alien and you don't need
  to understand it to use the data structure.  It's enough to know that the
  members on the module are documented here:

    http://ocaml-batteries-team.github.io/batteries-included/hdoc2/BatMap.S.html

  You can refer to these members by prefixing them with this module's name:
  EnvironmentMap.  For instance, you may write

    let m = StringMap.add "x" 4 (EnvironmentMap.empty) in
    StringMap.find "x" m

  to create a single-mapping dictionary called m and then look up the key
  "x" in that dictionary.  See the documentation above for more functions that
  you can use with an environment.
*)
module StringMap = Map.Make(
  struct
    type t = string
    let compare = Pervasives.compare
  end);;

module StringSet = Set.Make(
  struct
    type t = string
    let compare = Pervasives.compare
  end
  );;

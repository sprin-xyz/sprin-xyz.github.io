(** This file contains the definition of the compiler: the tool that translates
    an AST in our language into assembly language. *)

open Batteries;;

open AssemblyLanguage;;
open Asts;;
open ClosureConversion;;
open Environment;;
open Freshening;;
open Printf;;
open TypeCheck;;
open Utils;;
open Wellformedness;;

let rec stack_size_of_expr (e : expr) : int =
  match e with
  | EInt _ | EBool _ | EVar _ -> 0
  | EUnaryOp (OpPrint, e') -> max 4 (stack_size_of_expr e')
  | EUnaryOp (_, e') -> stack_size_of_expr e'
  | EBinaryOp (_, e1, e2) -> List.max [stack_size_of_expr e1; 4 + stack_size_of_expr e2; 8;]
  | ELet (_, e1, e2) ->  List.max [stack_size_of_expr e1; 4 + stack_size_of_expr e2;]
  | EIfNonZero (e1, e2, e3) -> List.max [stack_size_of_expr e1; stack_size_of_expr e2; stack_size_of_expr e3;]
  | EIf (e1, e2, e3) -> List.max [stack_size_of_expr e1; stack_size_of_expr e2; stack_size_of_expr e3;]
  | ETuple (exprs) -> 4 + List.max (List.map stack_size_of_expr exprs)
  | EAppl (fexpr, expr, bol) -> 8 + List.max [stack_size_of_expr fexpr; stack_size_of_expr expr;]
  | ELambda (_, _) -> failwith "reached an elambda in stack_size_of_expr"
  | ESet (e1, e2, e3) -> 12 + List.max [stack_size_of_expr e1; stack_size_of_expr e2; stack_size_of_expr e3;]
;;

let change_bird_pointer_to_machine (reg : register) : instruction list = 
  [AAnd(ArgRegister(reg), ArgConstant(0xfffffffc))]
;;

let change_machine_pointer_to_bird (reg : register) : instruction list = 
  [AOr(ArgRegister(reg), ArgConstant(0x1))]
;;

(* reg has machine int in it denoting number bytes to alloc *)
let check_alloc (reg : register) : instruction list =
  let safe_label = fresh_name "safety" in
  [AMov(ArgRegister(EAX), ArgRegister(reg))]
  @ [AMov(ArgRegister(ESI), ArgMemory(AddressByLabel("heap_cursor")))]
  @ [AMov(ArgRegister(EDI), ArgMemory(AddressByLabel("end_of_heap")))]
  @ [ASub(ArgRegister(EDI), ArgRegister(ESI))]
  @ [ACmp(ArgRegister(EAX), ArgRegister(EDI))]
  @ [AJle(ArgLabel(safe_label))]
  @ [APush(ArgRegister(EAX))]
  @ [AMov(ArgMemory(AddressByLabel("end_of_stack")), ArgRegister(ESP))]
  @ [ACall(ArgLabel("gc"))]
  @ [APop(ArgRegister(EAX))]
  @ [ALabel(ArgLabel(safe_label))]
;;

(* start has lowest memory addr to 0 out *)
let zero_memory (start : register) (numWords : int) : instruction list =
  [AMov(ArgRegister(EDI), ArgRegister(start))]
  @ [AXor(ArgRegister(EAX), ArgRegister(EAX))]
  @ [AMov(ArgRegister(ECX), ArgConstant(numWords))]
  @ [ARepStosd]
;;

let rec compile_expression (env : environment) (e : expr)
  : instruction list =

  match e with
  | EInt (i) -> [AMov(ArgRegister(EAX), ArgConstant(2*i))]
  | EBool (truthiness) -> (
    match truthiness with
    | true -> [AMov(ArgRegister(EAX), ArgConstant(0xffffffff))]
    | false -> [AMov(ArgRegister(EAX), ArgConstant(0x7fffffff))]
  )
  | EUnaryOp (unary, exp1) -> (
    let rest = compile_expression env exp1 in
    match unary with
    | OpAfter -> 
      rest 
      @ (assert_type_safety_of_eax TInt) 
      @ [AAdd(ArgRegister(EAX), ArgConstant(2*1))] 
      @ (assert_arithmetic_safety ())
    | OpBefore -> 
      rest 
      @ (assert_type_safety_of_eax TInt) 
      @ [ASub(ArgRegister(EAX), ArgConstant(2*1))] 
      @ (assert_arithmetic_safety ())
    | OpIsBool -> 
      rest 
      @ [AShl(ArgRegister(EAX), ArgConstant(30))]
      @ [AMov(ArgRegister(EBX), ArgRegister(EAX))]
      @ [AShl(ArgRegister(EBX), ArgConstant(1))]
      @ [AAnd(ArgRegister(EAX), ArgRegister(EBX))]
      @ [AOr(ArgRegister(EAX), ArgConstant(0x7FFFFFFF))]
    | OpIsInt -> 
      rest 
      @ [AShl(ArgRegister(EAX), ArgConstant(31))]
      @ [AOr(ArgRegister(EAX), ArgConstant(0x7fffffff))]
      @ [AXor(ArgRegister(EAX), ArgConstant(0x80000000))]
    | OpIsTuple -> 
      let yes_paladin = fresh_name "yes" in
      let no_lock = fresh_name "no" in
      let way_out = fresh_name "ugh" in
      rest 
      @ [AMov(ArgRegister(EDX), ArgRegister(EAX))]
      @ [AAnd(ArgRegister(EDX), ArgConstant(0x00000003))]
      @ [ACmp(ArgRegister(EDX), ArgConstant(0x00000001))]
      @ [AJne(ArgLabel(no_lock))]
      @ change_bird_pointer_to_machine EAX
      @ [AMov(ArgRegister(EDX), ArgMemory(AddressByRegister(EAX)))]
      @ [AAnd(ArgRegister(EDX), ArgConstant(0x80000000))]
      @ [ACmp(ArgRegister(EDX), ArgConstant(0x00000000))]
      @ [AJne(ArgLabel(no_lock))]
      @ [ALabel(ArgLabel(yes_paladin))]
      @ [AMov(ArgRegister(EAX), ArgConstant(0xffffffff))]
      @ [AJmp(ArgLabel(way_out))]
      @ [ALabel(ArgLabel(no_lock))]
      @ [AMov(ArgRegister(EAX), ArgConstant(0x7fffffff))]
      @ [ALabel(ArgLabel(way_out))]
    | OpPrint -> 
      let (env', offset_argument) = alloc_temp env in
      rest 
      @ [AMov(offset_argument, ArgRegister(EAX))]
      @ [APush(ArgRegister(EAX))]
      @ [ACall(ArgLabel("printValue"))]
      @ [AAdd(ArgRegister(ESP), ArgConstant(4))]
      @ [AMov(ArgRegister(EAX), offset_argument)]
      @ [AMovSizeDword(offset_argument, ArgConstant(0))]
    )
  | EBinaryOp (binary, exp1, exp2) ->
    let compiled_exp1 = compile_expression env exp1 in
    let (env', offset1_argument) = alloc_temp env in
    let compiled_exp2 = compile_expression env' exp2 in
    let (env'', offset2_argument) = alloc_temp env' in
    compiled_exp1
    @ [AMov(offset1_argument, ArgRegister(EAX))]
    @ compiled_exp2
    @ [AMov(offset2_argument, ArgRegister(EAX))]
    @ (
      match binary with
      | OpPlus | OpMinus | OpTimes | OpLessThan | OpGreaterThan | OpEqualTo ->
        [AMov(ArgRegister(EAX), offset2_argument)]
        @ (assert_type_safety_of_eax TInt)
        @ [AMov(ArgRegister(EAX), offset1_argument)]
        @ (assert_type_safety_of_eax TInt)
      | OpAnd | OpOr ->
        [AMov(ArgRegister(EAX), offset2_argument)]
        @ (assert_type_safety_of_eax TBool)
        @ [AMov(ArgRegister(EAX), offset1_argument)]
        @ (assert_type_safety_of_eax TBool)
      | OpTupleIndex -> (
        [AMov(ArgRegister(EAX), offset1_argument)]
        @ (assert_type_safety_of_eax TTuple)
        @ [AMov(ArgRegister(EAX), offset2_argument)]
        @ (assert_type_safety_of_eax TInt)
      )
    )
    @ (
      match binary with
      | OpPlus ->
        [AAdd(ArgRegister(EAX), offset2_argument)]
      | OpMinus ->
        [ASub(ArgRegister(EAX), offset2_argument)]
      | OpTimes ->
        [ASar(ArgRegister(EAX), ArgConstant(1)); AMul(ArgRegister(EAX), offset2_argument)]
      | OpLessThan -> 
        [ACmp(ArgRegister(EAX), offset2_argument)]
        @ [ASetl(ArgRegister(AL))]
        @ [AShl(ArgRegister(EAX), ArgConstant(31))]
        @ [AOr(ArgRegister(EAX), ArgConstant(0x7FFFFFFF))]
      | OpGreaterThan -> 
        [ACmp(ArgRegister(EAX), offset2_argument)]
        @ [ASetg(ArgRegister(AL))]
        @ [AShl(ArgRegister(EAX), ArgConstant(31))]
        @ [AOr(ArgRegister(EAX), ArgConstant(0x7FFFFFFF))]
      | OpEqualTo ->
        [ACmp(ArgRegister(EAX), offset2_argument)]
        @ [ASete(ArgRegister(AL))]
        @ [AShl(ArgRegister(EAX), ArgConstant(31))]
        @ [AOr(ArgRegister(EAX), ArgConstant(0x7FFFFFFF))]
      | OpAnd ->
        [AAnd(ArgRegister(EAX), offset2_argument)]
      | OpOr ->
        [AOr(ArgRegister(EAX), offset2_argument)]
      | OpTupleIndex -> 
        [AMov(ArgRegister(EBX), offset2_argument)]
        @ [ASar(ArgRegister(EBX), ArgConstant(1))]
        @ [AMov(ArgRegister(EAX), offset1_argument)]
        @ change_bird_pointer_to_machine EAX
        @ (assert_tuple_index_safety ())
        @ [AAdd(ArgRegister(EBX), ArgConstant(2))]
        @ [AMul(ArgRegister(EBX), ArgConstant(4))]
        @ [AAdd(ArgRegister(EAX), ArgRegister(EBX))]
        @ [AMov(ArgRegister(EAX), ArgMemory(AddressByRegister(EAX)))]
    )
    @ (
      match binary with
      | OpPlus | OpMinus | OpTimes -> (assert_arithmetic_safety ())
      | _ -> []
    )
    @ [AMovSizeDword(offset1_argument, ArgConstant(0))]
    @ [AMovSizeDword(offset2_argument, ArgConstant(0))]
  | ELet (x, exp1, exp2) ->
    let compiled_exp1 = compile_expression env exp1 in
    let (env', var_storage_argument) = alloc_var env x in
    let compiled_exp2 = compile_expression env' exp2 in
    compiled_exp1
    @ [AMov(var_storage_argument, ArgRegister(EAX))]
    @ compiled_exp2
    @ [AMovSizeDword(var_storage_argument, ArgConstant(0))]
  | EVar (x) ->
    let var_offset_argument = lookup_var env x in
    [AMov(ArgRegister(EAX), var_offset_argument)]
  | EIfNonZero (exp1, exp2, exp3) ->
    let compiled_exp1 = compile_expression env exp1 in
    let compiled_exp2 = compile_expression env exp2 in
    let compiled_exp3 = compile_expression env exp3 in
    let else_label = fresh_name "nzelse" in
    let end_label = fresh_name "nzend" in
    compiled_exp1
    @ (assert_type_safety_of_eax TInt)
    @ [ACmp(ArgRegister(EAX), ArgConstant(0))]
    @ [AJe(ArgLabel(else_label))]
    @ compiled_exp2
    @ [AJmp(ArgLabel(end_label))]
    @ [ALabel(ArgLabel(else_label))]
    @ compiled_exp3
    @ [ALabel(ArgLabel(end_label))]
  | EIf (exp1, exp2, exp3) -> 
    let compiled_exp1 = compile_expression env exp1 in
    let compiled_exp2 = compile_expression env exp2 in
    let compiled_exp3 = compile_expression env exp3 in
    let else_label = fresh_name "ifelse" in
    let end_label = fresh_name "ifend" in
    compiled_exp1
    @ (assert_type_safety_of_eax TBool)
    @ [ACmp(ArgRegister(EAX), ArgConstant(0x7FFFFFFF))]
    @ [AJe(ArgLabel(else_label))]
    @ compiled_exp2
    @ [AJmp(ArgLabel(end_label))]
    @ [ALabel(ArgLabel(else_label))]
    @ compiled_exp3
    @ [ALabel(ArgLabel(end_label))]
  | EAppl (fexpr, exp1, bol) -> 
    let f = compile_expression env fexpr in
    let (env', offset1_argument) = alloc_temp env in
    let e = compile_expression env' exp1 in 
    let (env'', offset2_argument) = alloc_temp env' in
    let num_params = get_num_function_params env'' in
    let there_be_darkness_taily = fresh_name "darkness_tco" in
    let there_be_darkness_heady = fresh_name "darkness_no_tco" in
    let there_be_darkness = fresh_name "darkness" in
    let we_done_here = fresh_name "we_done_here" in
    let theifstatement = if bol then (
    [AMov(ArgRegister(ESI), ArgConstant(num_params))]
    @ [ACmp(ArgRegister(ECX), ArgRegister(ESI))]
    @ [ALabel(ArgLabel(fresh_name "fuckoffjakeevenharder"))]
    @ [AJg(ArgLabel(there_be_darkness_heady))]


    @ [ALabel(ArgLabel(there_be_darkness_taily))]
    @ [AMov(ArgRegister(EBX), ArgRegister(EBP))]
    @ [AAdd(ArgRegister(EBX), ArgConstant(8))]
    @ zero_memory EBX num_params
    @ [AMov(ArgRegister(EDI), ArgRegister(EBX))]
    @ [AMov(ArgRegister(EAX), offset1_argument)]
    @ change_bird_pointer_to_machine EAX
    @ [AMov(ArgRegister(ESI), ArgRegister(EAX))]
    @ [AAdd(ArgRegister(ESI), ArgConstant(16))]
    @ [AMov(ArgRegister(ECX), ArgMemory(AddressByRegisterOffset(EAX, 8)))]
    @ [ASub(ArgRegister(ECX), ArgConstant(1))]
    @ [ARepMovsd]
    @ [AMov(ArgRegister(ECX), offset2_argument)]
    @ [AMov(ArgMemory(AddressByRegister(EDI)), ArgRegister(ECX))]

    @ [AMov(ArgRegister(EBX), ArgMemory(AddressByRegisterOffset(EAX, 12)))]

    (* zero out our stack *)
    @ [AMov(ArgRegister(EDI), ArgRegister(ESP))]
    @ [AMov(ArgRegister(ECX), ArgRegister(EBP))]
    @ [ASub(ArgRegister(ECX), ArgRegister(ESP))]
    @ [ASar(ArgRegister(ECX), ArgConstant(2))]
    @ [AXor(ArgRegister(EAX), ArgRegister(EAX))]
    @ [ARepStosd]

    @ [AMov(ArgRegister(ESP), ArgRegister(EBP))]
    @ [APop(ArgRegister(EBP))]
    @ [AJmp(ArgLabel("ebx"))]
    )
    else ( 
    []
    ) in
    f
    @ [AMov(offset1_argument, ArgRegister(EAX))]
    @ [ALabel(ArgLabel(fresh_name "fuckoffjake"))]
    @ e
    @ [AMov(offset2_argument, ArgRegister(EAX))]
    @ [AMov(ArgRegister(EAX), offset1_argument)]
    @ assert_type_safety_of_eax TFunc
    @ change_bird_pointer_to_machine EAX
    @ [AMov(ArgRegister(ECX), ArgMemory(AddressByRegister(EAX)))]
    @ [AAnd(ArgRegister(ECX), ArgConstant(0x7fffffff))]
    @ [AAdd(ArgRegister(ECX), ArgConstant(1))]
    @ [AMov(ArgRegister(EBX), ArgMemory(AddressByRegisterOffset(EAX, 8)))]
    @ [ACmp(ArgRegister(ECX), ArgRegister(EBX))]
    @ [AJe(ArgLabel(there_be_darkness))]
    @ [AMov(ArgRegister(EAX), ArgRegister(ECX))]
    @ [AAdd(ArgRegister(EAX), ArgConstant(4))]
    @ [AMul(ArgRegister(EAX), ArgConstant(4))]
    @ check_alloc EAX
    @ [AMov(ArgRegister(EAX), offset1_argument)]
    @ change_bird_pointer_to_machine EAX
    @ [AMov(ArgRegister(EDI), ArgMemory(AddressByLabel("heap_cursor")))]
    @ [AMov(ArgRegister(ESI), ArgRegister(EAX))]
    @ [AMov(ArgRegister(ECX), ArgMemory(AddressByRegister(EAX)))]
    @ [AAnd(ArgRegister(ECX), ArgConstant(0x7fffffff))]
    @ [AAdd(ArgRegister(ECX), ArgConstant(4))]
    @ [ARepMovsd]
    @ [AMov(ArgRegister(EAX), ArgMemory(AddressByLabel("heap_cursor")))]
    @ [AMov(ArgRegister(ECX), ArgMemory(AddressByRegister(EAX)))]
    @ [AAdd(ArgRegister(ECX), ArgConstant(1))]
    @ [AMov(ArgMemory(AddressByRegister(EAX)), ArgRegister(ECX))]
    @ [AMov(ArgRegister(EBX), offset2_argument)]
    @ [AMov(ArgMemory(AddressByRegister(EDI)), ArgRegister(EBX))]
    @ [AAdd(ArgRegister(EDI), ArgConstant(4))]
    @ [AMov(ArgMemory(AddressByLabel("heap_cursor")), ArgRegister(EDI))]
    @ [AOr(ArgRegister(EAX), ArgConstant(1))]
    @ [AJmp(ArgLabel(we_done_here))]
    @ [ALabel(ArgLabel(there_be_darkness))]

    @ theifstatement
    @ [ALabel(ArgLabel(there_be_darkness_heady))]
    @ [AMul(ArgRegister(EBX), ArgConstant(4))]
    @ [ASub(ArgRegister(ESP), ArgRegister(EBX))]
    @ [ASub(ArgRegister(ECX), ArgConstant(1))]
    @ [AMov(ArgRegister(ESI), ArgRegister(EAX))]
    @ [AAdd(ArgRegister(ESI), ArgConstant(16))]
    @ [AMov(ArgRegister(EDI), ArgRegister(ESP))]
    @ [ARepMovsd]
    @ [AMov(ArgRegister(ECX), offset2_argument)]
    @ [AMov(ArgMemory(AddressByRegister(EDI)), ArgRegister(ECX))]
    @ [AMov(ArgRegister(EAX), ArgMemory(AddressByRegisterOffset(EAX, 12)))]
    @ [ACall(ArgRegister(EAX))]
    @ [AMov(ArgRegister(EBX), offset1_argument)]
    @ change_bird_pointer_to_machine EBX
    @ [AMov(ArgRegister(ECX), ArgMemory(AddressByRegisterOffset(EBX, 8)))]
    @ [AMul(ArgRegister(ECX), ArgConstant(4))]
    @ [AAdd(ArgRegister(ESP), ArgRegister(ECX))]
    @ [ALabel(ArgLabel(we_done_here))]
    @ [AMovSizeDword(offset1_argument, ArgConstant(0))]
    @ [AMovSizeDword(offset2_argument, ArgConstant(0))]
  | ETuple (exprs) -> 
    let length = List.length exprs in
    let (env', pointer_offset_argument) = alloc_temp env in
    let compiled = List.map (compile_expression env') exprs in
    let zipped_compiled = List.combine (List.of_enum (2--(length+1))) compiled in
    let interleaven = List.concat (List.map (fun (index, instrs) -> 
      let machine_offset = (index) * 4  in
      instrs
      @ [AMov(ArgRegister(EBX), pointer_offset_argument)]
      @ change_bird_pointer_to_machine EBX
      @ [AMov(ArgMemory(AddressByRegisterOffset(EBX, machine_offset)), ArgRegister(EAX))]
    ) zipped_compiled) in
    [AMov(ArgRegister(EAX), ArgConstant((length + 2) * 4))]
    @ check_alloc EAX
    @ [AMov(ArgRegister(EAX), ArgMemory(AddressByLabel("heap_cursor")))]
    @ change_machine_pointer_to_bird EAX
    @ [AMov(pointer_offset_argument, ArgRegister(EAX))]
    @ change_bird_pointer_to_machine EAX
    @ [AMov(ArgRegister(EBX), ArgConstant(length))]
    @ [AMov(ArgMemory(AddressByRegister(EAX)), ArgRegister(EBX))] 
    @ [AMovSizeDword(ArgMemory(AddressByRegisterOffset(EAX, 4)), ArgConstant(0))]
    @ [AMov(ArgRegister(EBX), ArgRegister(EAX))]
    @ [AAdd(ArgRegister(EBX), ArgConstant((length + 2) * 4))]
    @ [AMov(ArgMemory(AddressByLabel("heap_cursor")), ArgRegister(EBX))]
    @ interleaven
    @ [AMov(ArgRegister(EAX), pointer_offset_argument)]
    @ change_machine_pointer_to_bird EAX
    @ [AMovSizeDword(pointer_offset_argument, ArgConstant(0))]
  | ELambda (_, _) -> failwith "reached an elambda in compile_expression"
  | ESet (exp1, exp2, exp3) ->
    let (env', pointer_offset_arg) = alloc_temp env in
    let (env'', pointer_offset_arg') = alloc_temp env' in
    let (env''', pointer_offset_arg'') = alloc_temp env'' in
    let compiled_exp1 = compile_expression env' exp1 in
    let compiled_exp2 = compile_expression env'' exp2 in
    let compiled_exp3 = compile_expression env''' exp3 in
    compiled_exp1
    @ assert_type_safety_of_eax TTuple
    @ [AMov(pointer_offset_arg, ArgRegister(EAX))]
    @ compiled_exp2
    @ assert_type_safety_of_eax TInt
    @ [AMov(pointer_offset_arg', ArgRegister(EAX))]
    @ [AShr(ArgRegister(EAX), ArgConstant(1))]
    @ [AMov(ArgRegister(EBX), ArgRegister(EAX))]
    @ [AMov(ArgRegister(EAX), pointer_offset_arg)]
    @ change_bird_pointer_to_machine EAX
    @ assert_tuple_index_safety ()
    @ compiled_exp3
    @ [AMov(pointer_offset_arg'', ArgRegister(EAX))]
    @ [AMov(ArgRegister(EAX), pointer_offset_arg)]
    @ change_bird_pointer_to_machine EAX
    @ [AMov(ArgRegister(EBX), pointer_offset_arg')]
    @ [AShr(ArgRegister(EBX), ArgConstant(1))]
    @ [AMov(ArgRegister(ECX), pointer_offset_arg'')]
    @ [AAdd(ArgRegister(EBX), ArgConstant(2))]
    @ [AMul(ArgRegister(EBX), ArgConstant(4))]
    @ [AAdd(ArgRegister(EAX), ArgRegister(EBX))]
    @ [AMov(ArgMemory(AddressByRegister(EAX)), ArgRegister(ECX))]
    @ [AMov(ArgRegister(EAX), ArgRegister(ECX))]
    @ [AMovSizeDword(pointer_offset_arg, ArgConstant(0))]
    @ [AMovSizeDword(pointer_offset_arg', ArgConstant(0))]
    @ [AMovSizeDword(pointer_offset_arg'', ArgConstant(0))]
;;

let compile_decl (env : environment) (decl : declaration) : instruction list =
  let DFunction(name, arguments, exp) = decl in
  let nums = List.of_enum (0--^(List.length arguments)) in
  let addresses = List.map (fun x -> 8 + 4*x) nums in
  let zipped = List.combine arguments addresses in
  let function_name = "function_" ^ name in
  let env' = List.fold_left (fun e (var, mem) -> alloc_function_argument e var mem) env zipped in
  let env'' = set_num_function_params env' (List.length arguments) in
  let stack_size_exp = stack_size_of_expr exp in
  [ALabel(ArgLabel(function_name))]
  @ [APush(ArgRegister(EBP))]
  @ [AMov(ArgRegister(EBP), ArgRegister(ESP))]
  @ [ASub(ArgRegister(ESP), ArgConstant(stack_size_exp))]
  @ zero_memory ESP (stack_size_exp / 4)
  @ (compile_expression env'' exp)
  @ [AAdd(ArgRegister(ESP), ArgConstant(stack_size_exp))]
  @ [APop(ArgRegister(EBP))]
  @ [ARet]
;;

let closure_of_decl (decl : declaration) : instruction list =
  let DFunction(name, arguments, exp) = decl in
  [AAlign(4)]
  @ [ALabel(ArgLabel("closure_" ^ name))]
  @ [ADd(["0x80000000"; "0x00000000"; string_of_int (List.length arguments); "function_" ^ name])]
;;

let compile_program (p : program) : instruction list =
  let Program(decls, e) = p in
  let decl_names = List.map (fun (DFunction(name, _, _)) -> name) decls in
  let decl_kvs = List.map (fun name -> (name, ArgLabelOffset("closure_" ^ name, 1))) decl_names in
  let global_warming = List.fold_left (fun acc (k, v) -> assign_name acc k v) empty_environment decl_kvs in
  let stack_size_of_e = stack_size_of_expr e in
  let compiled_decls = List.concat (List.map (compile_decl global_warming) decls) in
  let initial_closures = List.concat (List.map closure_of_decl decls) in
  let instructions = compile_expression global_warming e in
  [ASection("data")]
  @ [AAlign(4)]
  @ [ALabel(ArgLabel("heap_cursor"))]
  @ [ADd(["0"])]
  @ [ALabel(ArgLabel("start_of_heap"))]
  @ [ADd(["0"])]
  @ [ALabel(ArgLabel("end_of_heap"))]
  @ [ADd(["0"])]
  @ [ALabel(ArgLabel("start_of_stack"))]
  @ [ADd(["0"])]
  @ [ALabel(ArgLabel("end_of_stack"))]
  @ [ADd(["0"])]
  @ initial_closures
  @ [ASection("text")]
  @ [AGlobal("bird_main")]
  @ [AGlobal("heap_cursor")]
  @ [AGlobal("start_of_heap")]
  @ [AGlobal("end_of_heap")]
  @ [AGlobal("start_of_stack")]
  @ [AGlobal("end_of_stack")]
  @ [ALabel(ArgLabel("bird_main"))]
  @ [APush(ArgRegister(EBP))]
  @ [AMov(ArgRegister(EBP), ArgRegister(ESP))]
  @ [ASub(ArgRegister(ESP), ArgConstant(stack_size_of_e))]
  @ zero_memory ESP (stack_size_of_e / 4)
  @ [AMov(ArgRegister(EAX), ArgMemory(AddressByRegisterOffset(EBP, 8)))]
  @ [AMov(ArgMemory(AddressByLabel("heap_cursor")), ArgRegister(EAX))]
  @ [AMov(ArgMemory(AddressByLabel("start_of_heap")), ArgRegister(EAX))]
  @ [AMov(ArgRegister(EAX), ArgMemory(AddressByRegisterOffset(EBP, 12)))]
  @ [AMov(ArgMemory(AddressByLabel("end_of_heap")), ArgRegister(EAX))]
  @ [AMov(ArgMemory(AddressByLabel("start_of_stack")), ArgRegister(EBP))]
  @ instructions
  @ [AAdd(ArgRegister(ESP), ArgConstant(stack_size_of_e))]
  @ [APop(ArgRegister(EBP))]
  @ [ARet]
  @ compiled_decls
;;

let rec tco_expr (e : expr) : expr =
  match e with
  | ELet (x, exp1, EAppl(axpr1, axpr2, _)) -> 
    ELet(x, exp1, EAppl(axpr1, axpr2, true))
  | ELet (x, exp1, exp2) ->
    ELet(x, exp1, tco_expr exp2) 

  | EIfNonZero (x, EAppl(axpr1, axpr2, _), EAppl(axpr12, axpr22, _)) ->
    EIfNonZero (x, EAppl(axpr1, axpr2, true), EAppl(axpr12, axpr22, true))
  | EIfNonZero (x, exp1, EAppl(axpr1, axpr2, _)) ->
    EIfNonZero (x, tco_expr exp1, EAppl(axpr1, axpr2, true))
  | EIfNonZero(x, EAppl(axpr1, axpr2, _), exp2) ->
    EIfNonZero(x, EAppl(axpr1, axpr2, true), tco_expr exp2)
  | EIfNonZero (x, exp1, exp2) -> 
    EIfNonZero(x, tco_expr exp1, tco_expr exp2)
  
  | EIf (x, EAppl(axpr1, axpr2, _), EAppl(axpr12, axpr22, _)) ->
    EIf (x, EAppl(axpr1, axpr2, true), EAppl(axpr12, axpr22, true))
  | EIf (x, exp1, EAppl(axpr1, axpr2, _)) ->
    EIf (x, tco_expr exp1, EAppl(axpr1, axpr2, true))
  | EIf(x, EAppl(axpr1, axpr2, _), exp2) ->
    EIf(x, EAppl(axpr1, axpr2, true), tco_expr exp2)
  | EIf (x, exp1, exp2) -> 
    EIf(x, tco_expr exp1, tco_expr exp2) 

  | _ -> e
;;

let tco (p : program) : program =
  let Program(decls, e) = p in
  let f = fun (DFunction(a, b, c)) -> DFunction(a, b, tco_expr c) in
  Program(List.map f decls, e)
;;

let compile_to_assembly_code (p : program) : string =
  check_well_formed p;
  let no_lambda_p = no_russian p in
  let ppp = tco no_lambda_p in
  let instructions = compile_program ppp in
  let instruction_code = code_of_instruction_list instructions in
  "extern printValue\n" ^
  "extern stopWithError\n" ^ 
  "extern gc\n" ^
  instruction_code ^ "\n"
;;

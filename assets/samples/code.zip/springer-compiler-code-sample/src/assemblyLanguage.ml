(** This file contains type declarations and functions related to the compiler's
    representation of x86 assembly language. *)

open Batteries;;

(** Describes the registers of x86 that our code will use. *)
type register =
  | EAX
  | EBX
  | ECX
  | EDX
  | EDI
  | ESI
  | ESP
  | EBP
  | AL
;;

(** Describes a memory address expression in x86 assembly. *)
type address =
  | AddressByRegister of register
  | AddressByRegisterOffset of register * int
  | AddressByLabel of string
;;

(** Describes the type of arguments in our x86 assembly representation.  We use
    this type somewhat loosely: not every argument is valid everywhere an
    argument type is written below, but capturing the precise syntax limitations
    of x86 would make our assembly language types a lot more complicated. *)
type argument =
  | ArgConstant of int
  | ArgRegister of register
  | ArgMemory of address
  | ArgLabel of string
  | ArgLabelOffset of string * int
  | ArgSized of string * argument
;;

(** The type that represents single x86 instructions. *)
type instruction =
  | AMov of argument * argument
  | AMovSizeDword of argument * argument
  | AAdd of argument * argument
  | ASub of argument * argument
  | AMul of argument * argument
  | ALabel of argument
  | ACmp of argument * argument
  | AJmp of argument
  | AJe of argument
  | AJne of argument
  | AJge of argument
  | AJg of argument
  | AJl of argument
  | AJle of argument
  | APush of argument
  | APop of argument
  | AShl of argument * argument
  | AShr of argument * argument
  | ASal of argument * argument
  | ASar of argument * argument
  | ASetl of argument
  | ASetg of argument
  | ASete of argument
  | AAnd of argument * argument
  | AOr of argument * argument
  | AXor of argument * argument
  | AJo of argument 
  | AJno of argument 
  | ACall of argument 
  | ARet
  | ASection of string
  | AAlign of int
  | ADd of string list
  | AGlobal of string
  | ARepMovsd
  | ARepStosd
;;

(** A function which transforms an x86 register into a string suitable for
    writing into an assembly language file. *)
let code_of_register (register : register) : string =
  match register with
  | EAX -> "eax"
  | EBX -> "ebx"
  | ECX -> "ecx"
  | EDX -> "edx"
  | EDI -> "edi"
  | ESI -> "esi"
  | ESP -> "esp"
  | EBP -> "ebp"
  | AL -> "al"
;;

(** A function which transforms an x86 address expression into a string suitable
    for writing into an assembly language file. *)
let code_of_address (address : address) : string =
  match address with
  | AddressByRegister (reg) -> "[" ^ (code_of_register reg) ^ "]"
  | AddressByRegisterOffset (reg, i) ->
      "[" ^ (code_of_register reg) ^ " + " ^ (string_of_int i) ^ "]"
  | AddressByLabel (str) -> "[" ^ str ^ "]"
;;

(** A function which transforms an x86 argument into a string suitable for
    writing into an assembly language file. *)
let rec code_of_argument (argument : argument) : string =
  match argument with
  | ArgConstant (i) -> string_of_int i
  | ArgRegister (reg) -> code_of_register reg
  | ArgMemory (ad) -> code_of_address ad
  | ArgLabel (s) -> s
  | ArgLabelOffset (s, i) -> s ^ " + " ^ string_of_int i
  | ArgSized  (s, arg) -> s ^ " " ^ code_of_argument arg
;;

(** A function which transforms an x86 instruction into a string suitable for
    writing into an assembly language file. *)
let code_of_instruction (instruction : instruction) : string =
  match instruction with
  | AMov (arg1, arg2) ->
    "mov " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | AMovSizeDword(arg1, arg2) ->
    "mov " ^ code_of_argument arg1 ^ ", DWORD " ^ code_of_argument arg2
  | AAdd (arg1, arg2) ->
    "add " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | ASub (arg1, arg2) ->
    "sub " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | AMul (arg1, arg2) ->
    "imul " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | ALabel (label) ->
    code_of_argument label ^ ":"
  | ACmp (arg1, arg2) ->
    "cmp " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | AJmp (label) ->
    "jmp " ^ code_of_argument label
  | AJe (label) ->
    "je " ^ code_of_argument label
  | AJne (label) ->
    "jne " ^ code_of_argument label
  | AJge (label) ->
    "jge " ^ code_of_argument label
  | AJg (label) ->
    "jg " ^ code_of_argument label
  | AJl (label) ->
    "jl " ^ code_of_argument label
  | AJle (label) ->
    "jle " ^ code_of_argument label
  | APush (arg) -> 
    "push " ^ code_of_argument arg
  | APop (arg) -> 
    "pop " ^ code_of_argument arg
  | AShl (arg1, arg2) ->
    "shl " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | AShr (arg1, arg2) ->
    "shr " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | ASal (arg1, arg2) ->
    "sal " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | ASar (arg1, arg2) ->
    "sar " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | ASetl (arg) ->
    "setl " ^ code_of_argument arg
  | ASetg (arg) ->
    "setg " ^ code_of_argument arg
  | ASete (arg) ->
    "sete " ^ code_of_argument arg
  | AAnd (arg1, arg2) ->
    "and " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | AOr (arg1, arg2) ->
    "or " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | AXor (arg1, arg2) ->
    "xor " ^ code_of_argument arg1 ^ ", " ^ code_of_argument arg2
  | AJo (arg) -> 
    "jo " ^ code_of_argument arg
  | AJno (arg) -> 
    "jno " ^ code_of_argument arg
  | ACall (arg) -> 
    "call " ^ code_of_argument arg
  | ARet -> 
    "ret"
  | ASection (str) ->
    "section ." ^ str
  | AAlign (i) ->
    "align " ^ string_of_int i
  | ADd (strs) ->
    "dd " ^ String.concat ", " strs
  | AGlobal(str) ->
    "global " ^ str
  | ARepMovsd ->
    "rep movsd"
  | ARepStosd ->
    "rep stosd"
;;

(** A function which transforms a list of x86 instructions into a string
    suitable for writing into an assembly language file. *)
let code_of_instruction_list (instruction_list : instruction list) : string =
  String.concat "\n" (List.map code_of_instruction instruction_list)
;;

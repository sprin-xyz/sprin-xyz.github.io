open Batteries;;

open AssemblyLanguage;;
open Asts;;
open Environment;;
open Freshening;;
open Printf;;

type type_check = TInt | TBool | TTuple | TFunc;;

let assert_type_safety_of_eax (t : type_check) : instruction list =
    let safe_label = fresh_name "safe_type" in 
    let error_label = fresh_name "aDoneFuckedup" in

    [AMov(ArgRegister(EDX), ArgRegister(EAX))] @
    (match t with
    | TInt -> 
        [AAnd(ArgRegister(EDX), ArgConstant(0x00000001))]
        @ [ACmp(ArgRegister(EDX), ArgConstant(0x00000000))]
        @ [AJe(ArgLabel(safe_label))]
        @ [AMov(ArgRegister(EAX), ArgConstant(1))]
    | TBool ->
        [AAnd(ArgRegister(EDX), ArgConstant(0x00000003))]
        @ [ACmp(ArgRegister(EDX), ArgConstant(0x00000003))]
        @ [AJe(ArgLabel(safe_label))]
        @ [AMov(ArgRegister(EAX), ArgConstant(2))]
    | TTuple ->
        [AAnd(ArgRegister(EDX), ArgConstant(0x00000003))]
        @ [ACmp(ArgRegister(EDX), ArgConstant(0x00000001))]
        @ [AJne(ArgLabel(error_label))]
        @ [AMov(ArgRegister(EBX), ArgRegister(EAX))]
        @ [AAnd(ArgRegister(EBX), ArgConstant(0xfffffffc))]
        @ [AMov(ArgRegister(EDX), ArgMemory(AddressByRegister(EBX)))]
        @ [AAnd(ArgRegister(EDX), ArgConstant(0x80000000))]
        @ [ACmp(ArgRegister(EDX), ArgConstant(0x00000000))]
        @ [AJne(ArgLabel(error_label))]
        @ [AJmp(ArgLabel(safe_label))]
        @ [ALabel(ArgLabel(error_label))]
        @ [AMov(ArgRegister(EAX), ArgConstant(4))]
    | TFunc -> 
        [AAnd(ArgRegister(EDX), ArgConstant(0x00000003))]
        @ [ACmp(ArgRegister(EDX), ArgConstant(0x00000001))]
        @ [AJne(ArgLabel(error_label))]
        @ [AMov(ArgRegister(ECX), ArgRegister(EAX))]
        @ [AAnd(ArgRegister(ECX), ArgConstant(0xfffffffc))]
        @ [AMov(ArgRegister(EDX), ArgMemory(AddressByRegister(ECX)))]
        @ [AAnd(ArgRegister(EDX), ArgConstant(0x80000000))]
        @ [ACmp(ArgRegister(EDX), ArgConstant(0x80000000))]
        @ [AJne(ArgLabel(error_label))]
        @ [AJmp(ArgLabel(safe_label))]
        @ [ALabel(ArgLabel(error_label))]
        @ [AMov(ArgRegister(EAX), ArgConstant(6))]
    )
    @ [APush(ArgRegister(EAX))]
    @ [ACall(ArgLabel("stopWithError"))]
    @ [AAdd(ArgRegister(ESP), ArgConstant(4))]
    @ [ALabel(ArgLabel(safe_label))]
;;

let assert_arithmetic_safety () : instruction list =
    let safe_label = fresh_name "no_overflow" in
    let error_code = 3 in
    [AJno(ArgLabel(safe_label))]
    @ [AMov(ArgRegister(EAX), ArgConstant(error_code))]
    @ [APush(ArgRegister(EAX))]
    @ [ACall(ArgLabel("stopWithError"))]
    @ [AAdd(ArgRegister(ESP), ArgConstant(4))]
    @ [ALabel(ArgLabel(safe_label))]
;;

(* Assuming EAX has machine pointer and EBX has index as machine int*)
(* checks index not negative and not too large *)
let assert_tuple_index_safety () : instruction list =
    let safe_label = fresh_name "tuple_index_is_fine" in
    let error_label = fresh_name "tuple_index_is_FUBAR" in
    let error_code = 5 in
    [AMov(ArgRegister(ECX), ArgMemory(AddressByRegister(EAX)))]
    @ [ACmp(ArgRegister(EBX), ArgRegister(ECX))]
    @ [AJge(ArgLabel(error_label))]
    @ [ACmp(ArgRegister(EBX), ArgConstant(0))]
    @ [AJl(ArgLabel(error_label))]
    @ [AJmp(ArgLabel(safe_label))]
    @ [ALabel(ArgLabel(error_label))]
    @ [AMov(ArgRegister(EAX), ArgConstant(error_code))]
    @ [APush(ArgRegister(EAX))]
    @ [ACall(ArgLabel("stopWithError"))]
    @ [AAdd(ArgRegister(ESP), ArgConstant(4))]
    @ [ALabel(ArgLabel(safe_label))]
;;
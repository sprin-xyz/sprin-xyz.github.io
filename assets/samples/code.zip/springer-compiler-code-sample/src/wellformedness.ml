open Batteries;;

open Printf;;
open Environment;;
open Utils;;

open Asts;;

exception IllFormed of string list;;

let num_of_target (args : string list) (target : string) : int =
  List.sum ( List.map (fun x -> if x = target then 1 else 0) args)
;;

let zipped_duplicates (args : string list) : (string * int) list =
  let args_set = List.fold_left (fun x y -> StringSet.add y x) StringSet.empty args in
  let arg_set_as_list = StringSet.elements args_set in
  let arg_count = List.map (num_of_target args) arg_set_as_list in
  let args_zipped = List.combine arg_set_as_list arg_count in
  List.filter (fun (x, y) -> y > 1) args_zipped
;;

let check_decl_for_duplicate_params (args : string list) (func_name : string) : string list =
  let problematic = zipped_duplicates args in
  List.map (fun (x, _) -> "Function " ^ func_name ^ " declares a duplicate parameter " ^ x ^ ".") problematic
;;

let rec check_decls_for_duplicate_param (decls : declaration list) : string list =
  match decls with
  | [] -> []
  | DFunction(func_name, args, _) :: rest -> 
    check_decl_for_duplicate_params args func_name
    @ check_decls_for_duplicate_param rest
;;

let check_decls_for_duplicate_func_name (function_names : string list) : string list =
  let problematic = zipped_duplicates function_names in
  List.map (fun (x, _) -> "Duplicate definition of function " ^ x ^".") problematic
;;

let rec check_expression_for_unbound_vars (env : StringSet.t) (e : expr) : string list =
  match e with
  | EVar (x) -> 
    if StringSet.mem x env then
      []
    else
      ["Unbound variable " ^ x ^ "."]
  | ELet (x, e1, e2) -> 
    let env' = StringSet.add x env in
    check_expression_for_unbound_vars env e1
    @ check_expression_for_unbound_vars env' e2
  | EAppl (fexpr, exp1, bol) -> 
    check_expression_for_unbound_vars env fexpr
    @ check_expression_for_unbound_vars env exp1
  | EInt _ | EBool _ -> []
  | EUnaryOp (_, exp1) -> check_expression_for_unbound_vars env exp1
  | EBinaryOp (_, exp1, exp2) -> 
    check_expression_for_unbound_vars env exp1
    @ check_expression_for_unbound_vars env exp2
  | EIf (exp1, exp2, exp3) | EIfNonZero (exp1, exp2, exp3) | ESet(exp1, exp2, exp3) -> 
    check_expression_for_unbound_vars env exp1
    @ check_expression_for_unbound_vars env exp2
    @ check_expression_for_unbound_vars env exp3
  | ETuple (exprs) -> List.concat (List.map (check_expression_for_unbound_vars env) exprs)
  | ELambda (x, exp1) -> 
    let env' = StringSet.add x env in 
    check_expression_for_unbound_vars env' exp1
;;

(* This function produces a list of compile-time errors found in a program. *)
let check_program_for_errors (p : program) : string list =
  let Program(decls, exp) = p in
  let function_names_list = List.map (fun (DFunction(x, y, z)) -> x) decls in
  let function_names_set = List.fold_left (fun acc el -> StringSet.add el acc) StringSet.empty function_names_list in
  let function_names_exprs = List.map (fun (DFunction(x, y, z)) -> (y, z)) decls in
  check_decls_for_duplicate_param decls 
  @ check_decls_for_duplicate_func_name function_names_list
  @ check_expression_for_unbound_vars function_names_set exp
  @ List.concat (List.map 
    (fun (a, e) -> (check_expression_for_unbound_vars (List.fold_left (fun x y -> StringSet.add y x) function_names_set a) e))
    function_names_exprs)
;;

(* This function will check a program for compile-time errors.  If any errors
   are found, an IllFormed exception is thrown.  Otherwise, unit is returned. *)
let check_well_formed (p : program) : unit =
  let errors = check_program_for_errors p in
  if List.is_empty errors then () else raise (IllFormed errors);
;;

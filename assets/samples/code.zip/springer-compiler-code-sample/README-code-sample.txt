This repository contains code from a class project on building a compiler, 
which was completed over the course of a semester. The code was written by
myself and my lab partner. All code was produced by peer-programming; at all
times during the writing of the code, we were writing code together (i.e.,
we never worked independently from each other.) Some source files were
provided by the instructor, which I have marked at the top of those files
with a comment.

open TestUtils;;
open LLLexer;;
open OUnit2;;
open Asts;;
open LLParser;;

let test_initial_plus =
  "1+(2+3)" >:: fun _ ->
  assert_equal [TokInt(1); TokPlus; TokOpenParen; TokInt(2); TokPlus; TokInt(3); TokCloseParen;]
  (lex "1+(2+3)")
;;

let test_initial_plus_spaces =
  "1                         +          ( 2 + 3)            " >:: fun _ ->
  assert_equal [TokInt(1); TokPlus; TokOpenParen; TokInt(2); TokPlus; TokInt(3); TokCloseParen;]
  (lex " 1                         +          ( 2 + 3)            ")
;;

let test_let_identifier =
  "let lettuce=17 in lettuce" >:: fun _ ->
  assert_equal [TokLet; TokIdentifier("lettuce"); TokEquals; TokInt(17); TokIn; TokIdentifier("lettuce");]
  (lex "let lettuce=17 in lettuce")
;;

let test_fail_new_character =
  "1+2+3+^4+5+6" >:: fun _ ->
  assert_raises (LexerError "Unrecognized token starting at: \"^4+5+6\"")
  (fun _ -> lex "1+2+3+^4+5+6")
;;

let test_minus =
  "1-(3+5)" >:: fun _ ->
  assert_equal (Program([], EBinaryOp(OpMinus, EInt(1), EBinaryOp(OpPlus, EInt(3), EInt(5)))))
  (parse (lex "1-(3+5)"))
;;

let test_times =
  "1+2*3" >:: fun _ ->
  assert_equal (Program([], EBinaryOp(OpPlus, EInt(1), EBinaryOp(OpTimes, EInt(2), EInt(3)))))
  (parse (lex "1+2*3"))
;;

let test_20 =
  "(4 < 5) = 4 * 5" >:: fun _ ->
  assert_equal (Program([], 
  EBinaryOp(
    OpEqualTo, 
    EBinaryOp(OpLessThan, EInt(4), EInt(5)), 
    EBinaryOp(OpTimes, EInt(4), EInt(5))))
  )
  (parse (lex "(4 < 5) = 4 * 5"))
;;

let test_decls = 
  "def f a b = a + b end\n\ndef g g g g = g end     \n 4" >:: fun _ ->
  assert_equal ~printer:show_program
  (Program(
    [DFunction("f", ["a"; "b"], EBinaryOp(OpPlus, EVar("a"), EVar("b")));
      DFunction("g", ["g"; "g"; "g";], EVar("g"))],
    EInt(4)
  ))
  (parse (lex "def f a b = a + b end\n\ndef g g g g = g end     \n 4"))
;;

let test_decls_2 = 
  "def f a b = a + b end\n\ndef g g g g = g end     \n 4" >:: fun _ ->
  assert_equal ~printer:show_program
  (Program(
    [DFunction("f", ["a"; "b"], EBinaryOp(OpPlus, EVar("a"), EVar("b")));
      DFunction("g", ["g"; "g"; "g";], EAppl(EVar("g"), EVar("g"), false))],
    EInt(4)
  ))
  (parse (lex "def f a b = a + b end\n\ndef g g g g = g g end     \n 4"))
;;

let test_tuples = 
"let t = (4, 5 < 7, true) in 4" >:: fun _ ->
  assert_equal ~printer:show_program
  (Program([], ELet("t", ETuple([EInt(4); EBinaryOp(OpLessThan, EInt(5), EInt(7)); EBool(true)]), EInt(4))))
  (parse (lex "let t = (4, 5 < 7, true) in 4"))
;;

let test_tuple_set = 
"let t = (4, 5 < 7, true) in t[0] := 5" >:: fun _ ->
  assert_equal ~printer:show_program
  (Program([], ELet("t", ETuple([EInt(4); EBinaryOp(OpLessThan, EInt(5), EInt(7)); EBool(true)]), ESet(EVar("t"), EInt(0), EInt(5)))))
  (parse (lex "let t = (4, 5 < 7, true) in t[0] := 5"))
;;

let test_tuple_set2 = 
"let t = (4, 5 < 7, true) in let y = t[0] := 5 in y" >:: fun _ ->
  assert_equal ~printer:show_program
  (Program([], ELet("t", ETuple([EInt(4); EBinaryOp(OpLessThan, EInt(5), EInt(7)); EBool(true)]), ELet("y", ESet(EVar("t"), EInt(0), EInt(5)), EVar("y")))))
  (parse (lex "let t = (4, 5 < 7, true) in let y = t[0] := 5 in y"))
;;

let pyrrhuloxia_tests =
[
    test_initial_plus;
    test_initial_plus_spaces;
    test_let_identifier; 
    test_fail_new_character;
    test_minus;
    test_times;
    test_20;
    test_decls;
    test_decls_2;
    test_tuples;
    test_tuple_set;
    test_tuple_set2;
];;

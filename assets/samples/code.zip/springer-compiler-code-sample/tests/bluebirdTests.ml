open TestUtils;;

let bluebird_tests =
[
  test_success "test_code/bluebird/let1.bird" "1";
  test_success "test_code/bluebird/let2.bird" "64";
  test_compile_failure "test_code/bluebird/letfail.bird" "Unbound variable a.";
  test_success "test_code/bluebird/ifnz_non_0.bird" "73";
  test_success "test_code/bluebird/ifnz_0.bird" "10";
];;

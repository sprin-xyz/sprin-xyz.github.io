open TestUtils;;

let eagle_tests =
[
    test_success "test_code/eagle/e_given1.bird" "6";
    test_success "test_code/eagle/e_given2.bird" "(true, false)";
    test_success "test_code/eagle/e_given3.bird" "1\n2\n1\n";
    test_runtime_failure "test_code/eagle/e_given_failure1.bird" 4;
    test_runtime_failure "test_code/eagle/e_given_failure2.bird" 5;
    test_runtime_failure "test_code/eagle/e_given_failure3.bird" 1;
    test_runtime_failure "test_code/eagle/e_given_failure4.bird" 1;
    test_runtime_failure "test_code/eagle/e_given_failure5.bird" 4;
    test_runtime_failure "test_code/eagle/e_jake1.bird" 5;
    test_runtime_failure "test_code/eagle/e_jake2.bird" 5;
    test_success "test_code/eagle/e_jake3.bird" "(4, 6)";
    test_success "test_code/eagle/e_jake4.bird" "((1, 2, (3, 4, 5)), (6, (7, 8), 9))";
    test_success "test_code/eagle/e_jake5.bird" "11";
    test_success "test_code/eagle/e_jake6.bird" "(2, 1, true, 3, 0, 0, 0)\n(2, (1, (true, 3, false, true), false, true), (0, 0, 0))\n(3, 7, true)";
    test_success "test_code/eagle/e_jake7.bird" "1\n(7, (8, 9, false, true), false, true)\n1";
    test_success "test_code/eagle/e_jake8.bird" "(2, 1, true, 3, 0, 0, 0)\n(2, (1, (true, 3, false, true), false, true), (0, 0, 0))\n(3, 7, true)";
    test_success "test_code/eagle/e_jake9.bird" "(2, 1, true, 3, 0, 0, 0)\n(2, (1, (true, 3, true, false), true, false), (0, 0, 0))\n((3, 7, true), (3, 7, true))";
];;

open TestUtils;;

let cardinal_tests =
[
  test_success "test_code/cardinal/simple_true.bird" "true";
  test_success "test_code/cardinal/simple_false.bird" "false";
  test_success "test_code/cardinal/is_bool_true.bird" "true";
  test_success "test_code/cardinal/is_bool_false.bird" "false";
  test_success "test_code/cardinal/is_int_true.bird" "true";
  test_success "test_code/cardinal/is_int_false.bird" "false";
  test_success "test_code/cardinal/if_true.bird" "10\n10";
  test_success "test_code/cardinal/if_false.bird" "true\ntrue";
  test_success "test_code/cardinal/double_print.bird" "true\ntrue\ntrue";
  test_success "test_code/cardinal/stack_size.bird" "200\n200";
  test_success "test_code/cardinal/c_given.bird" "4\n10\n10";
  test_success "test_code/cardinal/doubling.bird" "1000000000\n1000000000";
  test_runtime_failure "test_code/cardinal/failure1.bird" 1;
  test_runtime_failure "test_code/cardinal/failure2.bird" 2;
  test_runtime_failure "test_code/cardinal/failure3.bird" 3;
  test_runtime_failure "test_code/cardinal/if_false_invalid_type.bird" 1;
  test_runtime_failure "test_code/cardinal/c_given2.bird" 2;
];;

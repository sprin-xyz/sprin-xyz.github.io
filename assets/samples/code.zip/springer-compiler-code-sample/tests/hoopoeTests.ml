open TestUtils;;

let hoopoe_tests =
[
  test_success "test_code/hoopoe/h_given1.bird" "1";
  test_success "test_code/hoopoe/h_given2.bird" "(10000003, true)";
  test_success "test_code/hoopoe/h_given3.bird" "12";
  test_success "test_code/hoopoe/h_given4.bird" "1";
  test_success "test_code/hoopoe/h_given5.bird" "6";
  test_success "test_code/hoopoe/h_jake1.bird" "200010000";
];;

open TestUtils;;

let gull_tests =
[
  test_success "test_code/gull/g_given1.bird" "12";
  (* test_success "test_code/gull/g_given2.bird" "?"; *) (* We expect to segfault, don't run with normal tests*)
  test_success "test_code/gull/g_given3.bird" "1048576";
  test_success "test_code/gull/g_given4.bird" "1048576";
  test_success "test_code/gull/g_zach1.bird" "(1, 2, 34)"; (* Test w/ 16 word heap *)
  test_success "test_code/gull/g_zach2.bird" "(1, (3, 3, 3), 2)"; (* Test w/ 16 word heap *)
  test_success "test_code/gull/g_zach3.bird" "5"; (* Test w/ 28 word heap *)
  test_success "test_code/gull/g_zach4.bird" "5"; (* Test w/ 28 word heap *)
  test_success "test_code/gull/g_zach5.bird" "(((false, 1), 2), 100)"; (* Test w/ 32 word heap *)
  test_success "test_code/gull/g_jake1.bird" "(1048576, 1)";
  test_success "test_code/gull/g_jake2.bird" "(1048576, 1)";
  test_success "test_code/gull/g_jake3.bird" "1048576";
  test_success "test_code/gull/g_jake4.bird" "(((((((((((((((((((((false, 1), 2), 4), 8), 16), 32), 64), 128), 256), 512), 1024), 2048), 4096), 8192), 16384), 32768), 65536), 131072), 262144), 524288), 100)";
  test_success "test_code/gull/g_jake5.bird" "(((((((((((((((((((((false, 1), 2), 4), 8), 16), 32), 64), 128), 256), 512), 1024), 2048), 4096), 8192), 16384), 32768), 65536), 131072), 262144), 524288), 100)";
];;

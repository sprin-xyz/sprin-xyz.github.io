open TestUtils;;

let dove_tests =
[
    test_success "test_code/dove/d_given1.bird" "5";
    test_success "test_code/dove/d_given2.bird" "18";
    test_success "test_code/dove/d_given3.bird" "15";
    test_success "test_code/dove/d_given4.bird" "1";
    test_success "test_code/dove/d_given5.bird" "true";
    test_compile_failure "test_code/dove/d_given_compile_fail3.bird" "Function f declares a duplicate parameter x.";
    test_compile_failure "test_code/dove/d_given_compile_fail4.bird" "Duplicate definition of function f.";
    test_compile_failure "test_code/dove/d_given_compile_fail5.bird" "Unbound variable y.";
    test_compile_failure "test_code/dove/d_given_compile_fail6.bird" "Unbound variable g.\nUnbound variable y.\nUnbound variable z.";
    test_compile_failure "test_code/dove/d_wefailed1.bird" "Unbound variable g.";
    test_runtime_failure "test_code/dove/d_wefailed2.bird" 6;
    test_success "test_code/dove/d_wefailed3.bird" "5\n4\n1";
    test_success "test_code/dove/d_i.bird" "16";
];;

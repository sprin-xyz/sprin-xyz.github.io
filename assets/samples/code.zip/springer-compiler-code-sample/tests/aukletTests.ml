open TestUtils;;

let auklet_tests =
[
  test_success "test_code/auklet/4.bird" "4";
  test_success "test_code/auklet/after_4.bird" "5";
  test_success "test_code/auklet/after_after_4.bird" "6";
  test_success "test_code/auklet/arithmetic.bird" "-9";
  test_success "test_code/auklet/before_4.bird" "3";
  test_success "test_code/auklet/before_after_4.bird" "4";
  test_success "test_code/auklet/minus1.bird" "3";
  test_success "test_code/auklet/minus2.bird" "-2";
  test_success "test_code/auklet/minus3.bird" "2";
  test_success "test_code/auklet/plus1.bird" "2";
  test_success "test_code/auklet/plus2.bird" "6";
  test_success "test_code/auklet/plus3.bird" "6";
  test_success "test_code/auklet/times1.bird" "8";
  test_success "test_code/auklet/times2.bird" "15";
];;

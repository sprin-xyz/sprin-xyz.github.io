open OUnit2;;
open AssemblyLanguage;;

let test_code_of_register_eax =
  "what if the register is EAX????" >:: fun _ ->
  assert_equal "eax" (code_of_register EAX)
;;

let test_code_of_register_esp =
  "what if the register is ESP????" >:: fun _ ->
  assert_equal "esp" (code_of_register ESP)
;;

let test_code_of_address_reg =
  "code of address: ?" >:: fun _ ->
  assert_equal "[eax]" (code_of_address (AddressByRegister(EAX)))
;;

let test_code_of_address_reg_offset_neg =
  "code of address: ? - ?" >:: fun _ ->
  assert_equal "[eax + -4]" (code_of_address (AddressByRegisterOffset(EAX, -4)))
;;

let test_code_of_address_reg_offset_pos =
  "code of address: ? + ?" >:: fun _ ->
  assert_equal "[eax + 4]" (code_of_address (AddressByRegisterOffset(EAX, 4)))
;;

let test_code_of_argument_constant =
  "code of argument: typeof === int" >:: fun _ ->
  assert_equal "10" (code_of_argument (ArgConstant(10)))
;;

let test_code_of_argument_register =
  "code of argument: typeof === register" >:: fun _ ->
  assert_equal "eax" (code_of_argument (ArgRegister(EAX)))
;;

let test_code_of_argument_memory =
  "code of argument: typeof === lack_of_alzheimers_smiley_face" >:: fun _ ->
  assert_equal "[eax + 4]"
  (code_of_argument (ArgMemory(AddressByRegisterOffset(EAX, 4))))
;;

let test_code_of_instruction_mov =
  "code of instruction: mov" >:: fun _ ->
  assert_equal "mov eax, esp"
  (code_of_instruction (AMov(ArgRegister(EAX), ArgRegister(ESP))))
;;

let test_code_of_instruction_add =
  "code of instruction: add" >:: fun _ ->
  assert_equal "add eax, esp"
  (code_of_instruction (AAdd(ArgRegister(EAX), ArgRegister(ESP))))
;;

let test_code_of_instruction_sub =
  "code of instruction: sub" >:: fun _ ->
  assert_equal "sub eax, esp"
  (code_of_instruction (ASub(ArgRegister(EAX), ArgRegister(ESP))))
;;

let test_code_of_instruction_mul =
  "code of instruction: imul" >:: fun _ ->
  assert_equal "imul eax, esp"
  (code_of_instruction (AMul(ArgRegister(EAX), ArgRegister(ESP))))
;;

let test_code_of_instruction_ret =
  "code of instruction: ret" >:: fun _ ->
  assert_equal "ret" (code_of_instruction ARet)
;;

let test_code_of_instruction_list =
  "code of instruction lists" >:: fun _ ->
  assert_equal "mov eax, esp\nret"
  (code_of_instruction_list [AMov(ArgRegister(EAX), ArgRegister(ESP)); ARet;])
;;

let assembly_language_tests = [
  test_code_of_register_eax;
  test_code_of_register_esp;
  test_code_of_address_reg;
  test_code_of_address_reg_offset_pos;
  test_code_of_address_reg_offset_neg;
  test_code_of_argument_constant;
  test_code_of_argument_register;
  test_code_of_argument_memory;

  test_code_of_instruction_mov;
  test_code_of_instruction_add;
  test_code_of_instruction_sub;
  test_code_of_instruction_mul;
  test_code_of_instruction_ret;

  test_code_of_instruction_list;
];;

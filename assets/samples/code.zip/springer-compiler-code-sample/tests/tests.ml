open AssemblyLanguageTests;;
open AukletTests;;
open BluebirdTests;;
open CardinalTests;;
open DoveTests;;
open EagleTests;;
open FalconTests;;
open GullTests;;
open HoopoeTests;;
open PyrrhuloxiaTests;;
open OUnit2;;

let all_tests =
  assembly_language_tests
  @ auklet_tests
  @ bluebird_tests
  @ cardinal_tests
  @ dove_tests
  @ eagle_tests
  @ falcon_tests
  @ gull_tests 
  @ hoopoe_tests
  @ pyrrhuloxia_tests
;;

let suite = "compiler test suite" >::: all_tests;;

run_test_tt_main suite;;

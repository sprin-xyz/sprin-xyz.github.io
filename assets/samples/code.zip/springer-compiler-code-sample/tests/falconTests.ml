open TestUtils;;

let falcon_tests =
[
  test_success "test_code/falcon/f_given1.bird" "6";
  test_success "test_code/falcon/f_given2.bird" "(4, 8)";
  test_runtime_failure "test_code/falcon/f_given_failure1.bird" 1;
  test_success "test_code/falcon/f_jake1.bird" "8";
  test_success "test_code/falcon/f_jake2.bird" "(2, 3, 4)";
  test_success "test_code/falcon/f_jake3.bird" "(false, true)";
  test_runtime_failure "test_code/falcon/f_jake4.bird" 6;
  test_success "test_code/falcon/f_jake5.bird" "500";
  test_success "test_code/falcon/f_jake6.bird" "2";
  test_success "test_code/falcon/f_fib.bird" "5";
  test_success "test_code/falcon/f_dave1.bird" "20";
  test_success "test_code/falcon/f_dave2.bird" "6";
  test_success "test_code/falcon/f_dave3.bird" "(4, 8)";
  test_success "test_code/falcon/f_dave4.bird" "22";
];;

#include <stdio.h>
#include "printer.h"

int bird_main(void* ptr, void*end) asm("bird_main");

int main(int argc, char** argv) {
  int size = sizeof(int) * 1048576;
  void* ptr = malloc(size);
  int result = bird_main(ptr, ptr + size);
  printValue(result);
  return 0;
}

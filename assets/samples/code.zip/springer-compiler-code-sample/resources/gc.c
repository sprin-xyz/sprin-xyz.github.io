// PART OF THIS FILE WAS PROVIDED BY THE INSTRUCTOR

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "error.h"

#define IS_PTR(x) ((((unsigned int)x) & 0x00000001) && (~((unsigned int)x) & 0x00000002))
#define bird_t unsigned int

// These extern declarations allow us to refer to the variables you made global
// in your generated assembly file.

extern bird_t* start_of_stack;
extern bird_t* end_of_stack;
extern bird_t* start_of_heap;
extern bird_t* end_of_heap;
extern bird_t* heap_cursor;

/*
  The following macros allow you to use "debugf" in place of "printf" for
  formatted debugging.  For instance, you can write

      debugf("Pointer %p changed to pointer %p.\n", old, new);

  to print in the same way you would use printf.  The advantage is that,
  depending upon which of the two macros you are using, the debugf call either
  turns into a printf call or is erased entirely.  Use debugf to print-debug
  your garbage collector and then disable printing when you need to perform your
  unit tests.
*/

// This macro disables all debugf statements.  (They become no-ops.)
#define debugf(fmt, ...) ;

// This macro enables all debugf statements.  (They become printf statements.)
// #define debugf(fmt, ...) printf(fmt, ##__VA_ARGS__); fflush(stdout)


/**
 * THIS METHOD WAS PROVIDED BY THE INSTRUCTOR
 * This helper function will show the entire contents of your heap.  This output
 * can get very large if your heap is too big!
 */
void dump_heap() {
  debugf("HEAP:\n");
  int c = 0;
  for (int* p = (int*)((unsigned int)start_of_heap & 0xFFFFFFF0);
       p < end_of_heap; p += 1) {
    if (c==0) {
      debugf("%08x:", p);
    }
    if (p >= start_of_heap) {
      debugf("    %08x", *p);
    } else {
      debugf("            ");
    }
    c++;
    if (c==8) {
      debugf("\n");
      c=0;
    }
  }
  if (c!=0) {
    debugf("\n");
  }
}

void dump_stack() {
  debugf("STACK: %08x %08x\n", start_of_stack, end_of_stack);
  int c = 0;
  for (int* p = (int*)((unsigned int)start_of_stack & 0xFFFFFFF0);
       p > end_of_stack; p -= 1) {
    if (c==0) {
      debugf("%08x:", p);
    }
    if (p <= start_of_stack) {
      debugf("    %08x", *p);
    } else {
      debugf("            ");
    }
    c++;
    if (c==8) {
      debugf("\n");
      c=0;
    }
  }
  if (c!=0) {
    debugf("\n");
  }
}

void dfsmark(bird_t start) {
  int len;
  if (IS_PTR(start)) {
    bird_t * ptr = (bird_t *)(start & 0xFFFFFFFC);
    if ((ptr < end_of_heap) && (ptr >= start_of_heap)) {
      if (ptr[1] == 0x0) {
        ptr[1] = 0x1;
        len = ptr[0] & 0x7FFFFFFF;
        if (ptr[0] & 0x80000000) {
          for (int i = 0; i < len; i++) {
            dfsmark(ptr[i+4]);
          }
        } else {
          for (int i = 0; i < len; i++) {
            dfsmark(ptr[i+2]);
          }
        }
      }
    }
  }
}

void gc(int desired_free) {
  debugf("\nDesire %d free bytes\nBefore anything: \n", desired_free);
  debugf("heap cursor: 0x%08x, start of heap: 0x%08x, end of heap: 0x%08x\n", heap_cursor, start_of_heap, end_of_heap);
  dump_stack();
  debugf("\n");
  dump_heap();
  for (bird_t * i = start_of_stack + 1; i >= end_of_stack; i -= 1) {
    dfsmark(*i);
  }
  debugf("\nAfter marking: \n");
  dump_heap();

  bird_t * next_heap_obj = start_of_heap;
  bird_t * next_live_dest = start_of_heap;
  int len;
  while (next_heap_obj < heap_cursor) {
    len = next_heap_obj[0] & 0x7FFFFFFF;
    if (next_heap_obj[0] & 0x80000000) {
      len += 4;
    } else {
      len += 2;
    }
    if (next_heap_obj[1] == 0x1) {
      next_heap_obj[1] = next_live_dest;
      next_live_dest += len;
    }
    next_heap_obj += len;
  }

  debugf("\nAfter forwarding: \n");
  dump_heap();
  for (bird_t * i = start_of_stack + 1; i >= end_of_stack; i -= 1) {
    if (IS_PTR(*i)) {
      bird_t* ptr = (bird_t *) ((*i) & 0xFFFFFFFC);
      if ((ptr < end_of_heap) && (ptr >= start_of_heap)) {
        *i = ptr[1] | 0x1;
      }
    }
  }

  next_heap_obj = start_of_heap;
  unsigned int metadata;
  while (next_heap_obj < heap_cursor) {
    len = next_heap_obj[0] & 0x7FFFFFFF;
    if (next_heap_obj[0] & 0x80000000) {
      metadata = 4;
    } else {
      metadata = 2;
    } 
    for (bird_t* j = next_heap_obj + metadata; j < next_heap_obj + metadata + len; j++) {
      if (IS_PTR(*j)) {
        bird_t* ptr = (bird_t *) ((*j) & 0xFFFFFFFC);
        if ((ptr < end_of_heap) && (ptr >= start_of_heap)) {
          *j = ptr[1] | 0x1;
        }
      }
    }
    len += metadata;
    next_heap_obj += len;
  }

  debugf("\nAfter updating: \n");
  dump_stack();
  dump_heap();

  next_heap_obj = start_of_heap;
  bird_t * live = start_of_heap;
  bird_t * live_end = start_of_heap;
  while (next_heap_obj < heap_cursor) {
    len = next_heap_obj[0] & 0x7FFFFFFF;
    if (next_heap_obj[0] & 0x80000000) {
      len += 4;
    } else {
      len += 2;
    }
    if (next_heap_obj[1] != 0x0) {
      live = next_heap_obj[1];
      live_end = live + len;
      memmove(live, next_heap_obj, len*4);
      live[1] = 0x0;
    }
    next_heap_obj += len;
  }
  memset(live_end, 0, 4 * (end_of_heap - live_end));
  /*for (bird_t * i = live_end; i < end_of_heap; i++) {
    *i = 0xBADBADFF;
  }*/
  if (4*(end_of_heap - live_end) < desired_free) {
    stopWithError(7);
  }
  heap_cursor = live_end;
  debugf("\n\n\n");
  dump_stack();
  dump_heap();
  debugf("\nheap cursor: 0x%08x, start of heap: 0x%08x, end of heap: 0x%08x\n", heap_cursor, start_of_heap, end_of_heap);
}

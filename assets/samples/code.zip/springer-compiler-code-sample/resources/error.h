#ifndef _ERROR_H_
#define _ERROR_H_

void stopWithError(int type) asm("stopWithError");

#endif
